const test = require('node:test');
const assert = require('node:assert/strict');
const vm = require('node:vm');
const fs = require('node:fs');
const path = require('node:path');

const script = fs.readFileSync(path.join(__dirname,'../app/src/main/assets/native-bridge.js'), 'utf8');

function setup() {
  const recorded = [];
  const callbacks = [];
  let activeId = '';
  let paused = false;
  let stopped = '';
  const db = [];
  const map = new Map();
  const storage = {
    getItem: k => map.has(k) ? map.get(k) : null,
    setItem: (k,v) => map.set(k,String(v)),
    removeItem: k => map.delete(k),
  };
  const host = {
    onmessage: null,
    postMessage(body) {
      const req = JSON.parse(body);
      recorded.push(req);
      let data = {};
      switch (req.action) {
        case 'geo-watch': data={subscribed:true}; break;
        case 'geo-unwatch': data={subscribed:false}; break;
        case 'geo-current': data={lat:35.197,lng:126.821,accuracy:9,t:1760000000000}; break;
        case 'start': activeId=req.tripId; stopped=''; break;
        case 'pause': paused=req.paused; break;
        case 'stop': stopped=activeId; activeId=''; break;
        case 'state': data={activeId,paused,lastStoppedId:stopped}; break;
        case 'points': data={points:db.filter(p=>p.seq>req.afterSeq).slice(0,req.limit)}; break;
      }
      queueMicrotask(() => host.onmessage({data:JSON.stringify({id:req.id,ok:true,data})}));
    }
  };
  const realGeo = {
    watchPosition(cb) { callbacks.push(cb); return callbacks.length; },
    clearWatch() {},
    getCurrentPosition(callback) { callback({coords:{latitude:35,lng:126},timestamp:Date.now()}); }
  };
  const ctx = {
    window:{ RiderSpotHost:host, addEventListener(){} },
    navigator:{geolocation:realGeo},
    document:{body:null,addEventListener(){}},
    sessionStorage:storage,
    localStorage:storage,
    console,
    Promise,
    JSON,
    Map,
    Object,
    setTimeout,
    clearTimeout,
    setInterval:()=>1,
    queueMicrotask,
  };
  vm.createContext(ctx);
  vm.runInContext(script,ctx);
  return {ctx,recorded,callbacks,db,storage,getActive:()=>activeId};
}

test('native start, locked-screen GPS point replay, pause and finish are wired to the existing ride API', async () => {
  const {ctx,recorded,db,getActive} = setup();
  const id = '11111111-1111-4111-8111-111111111111';
  const added=[];
  const api={
    trip:null,paused:false,
    async startTrip() { api.trip={id}; },
    togglePause(){api.paused=!api.paused;},
    async finish(){api.trip=null;}
  };
  ctx.window.__rsRideApi = api;
  const watch = ctx.navigator.geolocation.watchPosition(p=>added.push(p),()=>{},{});
  assert.equal(typeof watch,'number');
  await api.startTrip();
  assert.equal(getActive(),id);
  db.push({seq:1,lat:35.1,lng:126.9,accuracy:9,t:1760000000000});
  await ctx.window.__rsNativeResume();
  await new Promise(r=>setTimeout(r,30));
  assert.equal(added.length,1);
  assert.equal(added[0].coords.latitude,35.1);
  api.togglePause();
  await new Promise(r=>setTimeout(r,10));
  assert.ok(recorded.some(r=>r.action==='pause'&&r.paused));
  await api.finish();
  assert.equal(getActive(),'');
  assert.ok(recorded.some(r=>r.action==='stop'&&r.tripId===id));
});


test('foreground GPS is delivered from the Android bridge, not Chrome WebView geolocation', async () => {
  const {ctx,recorded,callbacks} = setup();
  const fixes = [];
  const errors = [];
  const id = ctx.navigator.geolocation.watchPosition(p => fixes.push(p), e => errors.push(e));
  await new Promise(resolve => setTimeout(resolve, 10));
  assert.equal(callbacks.length, 0, 'do not start a WebView geolocation watch');
  assert.ok(recorded.some(r => r.action === 'geo-watch'));
  ctx.window.__rsNativePosition({lat:35.21, lng:126.81, accuracy:8, t:1760000000000});
  assert.equal(fixes.length, 1);
  assert.equal(fixes[0].coords.latitude, 35.21);
  assert.equal(fixes[0].coords.longitude, 126.81);
  ctx.navigator.geolocation.clearWatch(id);
  await new Promise(resolve => setTimeout(resolve, 10));
  assert.ok(recorded.some(r => r.action === 'geo-unwatch'));
  assert.deepEqual(errors, []);
});

test('one-time current GPS is read from Android, with no Chrome permission dependency', async () => {
  const {ctx,recorded} = setup();
  const fix = await new Promise((resolve,reject) => {
    ctx.navigator.geolocation.getCurrentPosition(resolve,reject,{enableHighAccuracy:true});
  });
  assert.equal(fix.coords.latitude, 35.197);
  assert.equal(fix.coords.longitude, 126.821);
  assert.ok(recorded.some(r => r.action === 'geo-current'));
});

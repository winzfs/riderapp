const test = require('node:test');
const assert = require('node:assert/strict');
const vm = require('node:vm');
const fs = require('node:fs');
const path = require('node:path');

const script = fs.readFileSync(path.join(__dirname,'../app/src/main/assets/native-bridge.js'), 'utf8');

function setup() {
  const recorded = [];
  const callbacks = [];
  let activeId = '';
  let paused = false;
  let stopped = '';
  const db = [];
  const map = new Map();
  const storage = {
    getItem: k => map.has(k) ? map.get(k) : null,
    setItem: (k,v) => map.set(k,String(v)),
    removeItem: k => map.delete(k),
  };
  const host = {
    onmessage: null,
    postMessage(body) {
      const req = JSON.parse(body);
      recorded.push(req);
      let data = {};
      switch (req.action) {
        case 'geo-watch': data={subscribed:true}; break;
        case 'geo-unwatch': data={subscribed:false}; break;
        case 'geo-current': data={lat:35.197,lng:126.821,accuracy:9,t:1760000000000}; break;
        case 'start': activeId=req.tripId; stopped=''; break;
        case 'pause': paused=req.paused; break;
        case 'stop': stopped=activeId; activeId=''; break;
        case 'state': data={activeId,paused,lastStoppedId:stopped}; break;
        case 'points': data={points:db.filter(p=>p.seq>req.afterSeq).slice(0,req.limit)}; break;
      }
      queueMicrotask(() => host.onmessage({data:JSON.stringify({id:req.id,ok:true,data})}));
    }
  };
  const realGeo = {
    watchPosition(cb) { callbacks.push(cb); return callbacks.length; },
    clearWatch() {},
    getCurrentPosition(callback) { callback({coords:{latitude:35,lng:126},timestamp:Date.now()}); }
  };
  const ctx = {
    window:{ RiderSpotHost:host, addEventListener(){}, dispatchEvent(){} },
    navigator:{geolocation:realGeo},
    document:{body:null,addEventListener(){}},
    sessionStorage:storage,
    localStorage:storage,
    location:{origin:'https://rider-spot.jazzhjm.workers.dev'},
    console,
    Promise,
    JSON,
    Map,
    Object,
    setTimeout,
    clearTimeout,
    setInterval:()=>1,
    queueMicrotask,
    Event: class Event { constructor(type) { this.type = type; } },
  };
  vm.createContext(ctx);
  vm.runInContext(script,ctx);
  return {ctx,recorded,callbacks,db,storage,getActive:()=>activeId};
}

test('native start, locked-screen GPS point replay, pause and finish are wired to the existing ride API', async () => {
  const {ctx,recorded,db,getActive} = setup();
  const id = '11111111-1111-4111-8111-111111111111';
  const added=[];
  const api={
    trip:null,paused:false,
    async startTrip() { api.trip={id}; },
    togglePause(){api.paused=!api.paused;},
    async finish(){api.trip=null;}
  };
  ctx.window.__rsRideApi = api;
  const watch = ctx.navigator.geolocation.watchPosition(p=>added.push(p),()=>{},{});
  assert.equal(typeof watch,'number');
  await api.startTrip();
  assert.equal(getActive(),id);
  db.push({seq:1,lat:35.1,lng:126.9,accuracy:9,t:1760000000000});
  await ctx.window.__rsNativeResume();
  await new Promise(r=>setTimeout(r,30));
  assert.equal(added.length,1);
  assert.equal(added[0].coords.latitude,35.1);
  api.togglePause();
  await new Promise(r=>setTimeout(r,10));
  assert.ok(recorded.some(r=>r.action==='pause'&&r.paused));
  await api.finish();
  assert.equal(getActive(),'');
  assert.ok(recorded.some(r=>r.action==='stop'&&r.tripId===id));
});


test('foreground GPS is delivered from the Android bridge, not Chrome WebView geolocation', async () => {
  const {ctx,recorded,callbacks} = setup();
  const fixes = [];
  const errors = [];
  const id = ctx.navigator.geolocation.watchPosition(p => fixes.push(p), e => errors.push(e));
  await new Promise(resolve => setTimeout(resolve, 10));
  assert.equal(callbacks.length, 0, 'do not start a WebView geolocation watch');
  assert.ok(recorded.some(r => r.action === 'geo-watch'));
  ctx.window.__rsNativePosition({lat:35.21, lng:126.81, accuracy:8, t:1760000000000});
  assert.equal(fixes.length, 1);
  assert.equal(fixes[0].coords.latitude, 35.21);
  assert.equal(fixes[0].coords.longitude, 126.81);
  ctx.navigator.geolocation.clearWatch(id);
  await new Promise(resolve => setTimeout(resolve, 10));
  assert.ok(recorded.some(r => r.action === 'geo-unwatch'));
  assert.deepEqual(errors, []);
});

test('one-time current GPS is read from Android, with no Chrome permission dependency', async () => {
  const {ctx,recorded} = setup();
  const fix = await new Promise((resolve,reject) => {
    ctx.navigator.geolocation.getCurrentPosition(resolve,reject,{enableHighAccuracy:true});
  });
  assert.equal(fix.coords.latitude, 35.197);
  assert.equal(fix.coords.longitude, 126.821);
  assert.ok(recorded.some(r => r.action === 'geo-current'));
});


test('finishing merges screen-off SQLite points into both local history and Supabase', async () => {
  const {ctx,db,storage} = setup();
  const id = '33333333-3333-4333-8333-333333333333';
  const userId = '77777777-7777-4777-8777-777777777777';
  const t0=1794813422000;
  const uploads=[];
  const events=[];
  ctx.window.dispatchEvent = e => events.push(e.type);
  ctx.window.__rsClient = {
    auth:{getUser:async()=>({data:{user:{id:userId}}})},
    from:table=>({upsert:async record=>{
      assert.equal(table,'trips'); uploads.push(record); return {error:null};
    }})
  };
  ctx.window.__rsRideApi={
    trip:{id},paused:false,
    async startTrip(){},togglePause(){},
    async finish(){
      const original={id,user_id:userId,started_at:new Date(t0).toISOString(),ended_at:new Date(t0+120000).toISOString(),distance_km:0,points:[{t:t0,lat:35.1,lng:126.8}],events:[]};
      storage.setItem('trips:'+userId,JSON.stringify([original]));
      this.trip=null;
    }
  };
  db.push({seq:1,t:t0+5000,lat:35.1001,lng:126.8001,accuracy:8});
  db.push({seq:2,t:t0+60000,lat:35.101,lng:126.802,accuracy:7});
  db.push({seq:3,t:t0+110000,lat:35.104,lng:126.806,accuracy:9});
  await ctx.window.__rsRideApi.finish();
  const history=JSON.parse(storage.getItem('trips:'+userId));
  assert.equal(history.length,1);
  assert.equal(history[0].points.length,4);
  assert.ok(history[0].distance_km>0);
  assert.equal(uploads.length,1);
  assert.equal(uploads[0].points.length,4);
  assert.equal(uploads[0].user_id,userId);
  assert.equal(storage.getItem('rs:pending:trips:'+userId),'[]');
  assert.deepEqual(events,[]);
});

test('network failure keeps the COMPLETE route queued for retry without losing samples', async () => {
  const {ctx,db,storage} = setup();
  const id = '33333333-3333-4333-8333-333333333333';
  const userId='77777777-7777-4777-8777-777777777777';
  const t0=1794813422000, events=[];
  ctx.window.dispatchEvent=e=>events.push(e.type);
  ctx.window.__rsClient={
    auth:{getUser:async()=>({data:{user:{id:userId}}})},
    from:()=>({upsert:async()=>({error:new Error('offline')})})
  };
  ctx.window.__rsRideApi={trip:{id},paused:false,
    async finish(){storage.setItem('trips:'+userId,JSON.stringify([{id,user_id:userId,ended_at:new Date(t0+80000).toISOString(),started_at:new Date(t0).toISOString(),points:[],events:[],distance_km:0}]));this.trip=null;}
  };
  db.push({seq:1,t:t0,lat:35.1,lng:126.8,accuracy:8});
  db.push({seq:2,t:t0+70000,lat:35.11,lng:126.82,accuracy:9});
  await ctx.window.__rsRideApi.finish();
  assert.deepEqual(JSON.parse(storage.getItem('rs:pending:trips:'+userId)),[id]);
  assert.equal(JSON.parse(storage.getItem('trips:'+userId))[0].points.length,2);
  assert.ok(events.includes('riderspot:trip-pending'));
});

test('no trip-route write to Supabase while recording, including GPS replay and pause', async () => {
  const {ctx,db} = setup();
  const id='33333333-3333-4333-8333-333333333333';
  const userId='77777777-7777-4777-8777-777777777777';
  const uploads=[];
  ctx.window.__rsClient={
    auth:{getUser:async()=>({data:{user:{id:userId}}})},
    from:()=>({upsert:async record=>{uploads.push(record);return {error:null};}})
  };
  const api={trip:{id},paused:false,
    async startTrip(){},
    togglePause(){this.paused=!this.paused;},
    async finish(){}
  };
  ctx.window.__rsRideApi=api;
  ctx.navigator.geolocation.watchPosition(()=>{},()=>{});
  db.push({seq:1,t:1794813422000,lat:35.1,lng:126.8,accuracy:5});
  await ctx.window.__rsNativeResume();
  await new Promise(r=>setTimeout(r,15));
  api.togglePause();
  await new Promise(r=>setTimeout(r,15));
  assert.equal(uploads.length,0);
});

test('notification end finishes local trip, then synchronizes complete SQLite route', async () => {
  const {ctx,db,storage,recorded} = setup();
  const id='33333333-3333-4333-8333-333333333333';
  const userId='77777777-7777-4777-8777-777777777777';
  const t0=1794813422000;
  const uploads=[];
  let finished=0;
  ctx.window.__rsClient={
    auth:{getUser:async()=>({data:{user:{id:userId}}})},
    from:table=>({upsert:async record=>{assert.equal(table,'trips');uploads.push(record);return {error:null};}})
  };
  const api={trip:{id},paused:false,
    async finish(){
      finished++;
      storage.setItem('trips:'+userId,JSON.stringify([{
        id,user_id:userId,started_at:new Date(t0).toISOString(),
        ended_at:new Date(t0+120000).toISOString(),distance_km:0,
        points:[],events:[]
      }]));
      this.trip=null;
    }
  };
  ctx.window.__rsRideApi=api;
  // Simulate native service recording while screen is locked and stopping
  // immediately on a notification action, before WebView gets a callback.
  const initialCalls=recorded.length;
  db.push({seq:1,t:t0,lat:35.1,lng:126.8,accuracy:8});
  db.push({seq:2,t:t0+60000,lat:35.102,lng:126.805,accuracy:7});
  db.push({seq:3,t:t0+110000,lat:35.104,lng:126.81,accuracy:8});
  // mock state provider needs activeTrip to be initially started
  // and then stopped by notification (without WebView finish()).
  // Reuse native protocol: start, stop, then trigger UI reconciliation.
  const invoke=async(action,tripId)=> {
    return new Promise((resolve)=>{
      const reqId=99000+recorded.length;
      ctx.window.RiderSpotHost.onmessage({data:JSON.stringify({id:reqId,ok:true,data:{}})});
      ctx.window.RiderSpotHost.postMessage(JSON.stringify({id:reqId,action,tripId}));
      setTimeout(resolve,5);
    });
  };
  await invoke('start',id);
  await invoke('stop',id);
  await ctx.window.__rsNativeResume();
  await new Promise(r=>setTimeout(r,45));
  assert.equal(finished,1);
  assert.equal(uploads.length,1);
  assert.equal(uploads[0].points.length,3);
  assert.equal(storage.getItem('rs:pending:trips:'+userId),'[]');
  assert.ok(recorded.slice(initialCalls).some(x=>x.action==='points'));
});

test('notification action launches Activity and stops recording; foreground service remains declared', () => {
  const java = fs.readFileSync(path.join(__dirname,'../app/src/main/java/com/riderspot/android/TrackingService.java'),'utf8');
  const activity = fs.readFileSync(path.join(__dirname,'../app/src/main/java/com/riderspot/android/MainActivity.java'),'utf8');
  const manifest = fs.readFileSync(path.join(__dirname,'../app/src/main/AndroidManifest.xml'),'utf8');
  assert.match(java,/PendingIntent\.getActivity\(this, 2, stop/);
  assert.match(java,/"운행 종료"/);
  assert.match(activity,/ACTION_FINISH_FROM_NOTIFICATION/);
  assert.match(activity,/store\.stopTrip\(active\)/);
  assert.match(manifest,/android:foregroundServiceType="location"/);
});


test('Google OAuth uses external browser with existing allowed website redirect', async () => {
  const {ctx,recorded} = setup();
  const calls=[];
  const destination='https://qkcqzhkvfbymzjdktshp.supabase.co/auth/v1/authorize?provider=google&redirect_to=https%3A%2F%2Frider-spot.jazzhjm.workers.dev%2F';
  const client={auth:{async signInWithOAuth(req){calls.push(req);return {data:{url:destination},error:null};}}};
  ctx.window.__rsClient=client;
  const out=await client.auth.signInWithOAuth({provider:'google',options:{redirectTo:'https://rider-spot.jazzhjm.workers.dev/'}});
  assert.equal(out.error,null);
  assert.equal(calls.length,1);
  assert.equal(calls[0].options.skipBrowserRedirect,true);
  assert.equal(calls[0].options.redirectTo,'https://rider-spot.jazzhjm.workers.dev/');
  assert.ok(recorded.some(x=>x.action==='oauth-open'&&x.url===destination));
});

test('non-Google OAuth retains its original behavior', async () => {
  const {ctx,recorded} = setup();
  let called='';
  ctx.window.__rsClient={auth:{async signInWithOAuth(req){called=req.provider;return {data:{url:'https://other.test'},error:null};}}};
  await ctx.window.__rsClient.auth.signInWithOAuth({provider:'github'});
  assert.equal(called,'github');
  assert.ok(!recorded.some(x=>x.action==='oauth-open'));
});

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const path = require('node:path');
const source = fs.readFileSync(path.join(__dirname,'../server/native-oauth-worker.js'),'utf8');
const ctx = vm.createContext({Response,Request,URL,console});
vm.runInContext(source+'\nglobalThis.oauth = handleRiderSpotOAuth;',ctx);
const nonce='a'.repeat(32);
const oauthTarget='https://qkcqzhkvfbymzjdktshp.supabase.co/auth/v1/authorize?provider=google&redirect_to='+encodeURIComponent('https://rider-spot.jazzhjm.workers.dev/');
function start(target=oauthTarget,state=nonce){ return new Request('https://rider-spot.jazzhjm.workers.dev/__rs_android_oauth_start?state='+state+'&target='+encodeURIComponent(target)); }
test('login start sets short-lived, HttpOnly nonce cookie and preserves approved Supabase URL',async()=>{
  const res=await ctx.oauth(start(),new URL(start().url));
  assert.equal(res.status,302);
  assert.equal(res.headers.get('location'),oauthTarget);
  assert.match(res.headers.get('set-cookie'),/HttpOnly; SameSite=Lax/);
  assert.match(res.headers.get('cache-control'),/no-store/);
});
test('disallows arbitrary redirects, invalid states and providers',async()=>{
  for (const target of ['https://example.com/steal?provider=google&redirect_to=https://rider-spot.jazzhjm.workers.dev/',oauthTarget.replace('provider=google','provider=github'),oauthTarget.replace('redirect_to=','redirect_to=evil')]) {
    const req=start(target);assert.equal((await ctx.oauth(req,new URL(req.url))).status,400);
  }
  const req=start(oauthTarget,'x');assert.equal((await ctx.oauth(req,new URL(req.url))).status,400);
});
test('callback only hijacks browser with valid login cookie; no tokens in HTTP response',async()=>{
  const url='https://rider-spot.jazzhjm.workers.dev/';
  assert.equal(await ctx.oauth(new Request(url),new URL(url)),null);
  const req=new Request(url,{headers:{Cookie:'rs_android_oauth='+nonce}});
  const res=await ctx.oauth(req,new URL(url));
  assert.equal(res.status,200);
  assert.match(res.headers.get('set-cookie'),/Max-Age=0/);
  assert.match(await res.text(),/riderspot-oauth:\/\/signin\/callback/);
});
test('APK declares a browsable OAuth return and Java validates nonce',()=>{
  const manifest=fs.readFileSync(path.join(__dirname,'../app/src/main/AndroidManifest.xml'),'utf8');
  const java=fs.readFileSync(path.join(__dirname,'../app/src/main/java/com/riderspot/android/MainActivity.java'),'utf8');
  assert.match(manifest,/android:scheme="riderspot-oauth"/);
  assert.match(java,/actual\.equals\(expected\)/);
  assert.match(java,/client\.auth\.setSession/);
  assert.match(java,/OAUTH_STATE_TIME_KEY/);
});

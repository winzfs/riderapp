const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const vm=require('node:vm');
const script=fs.readFileSync(path.join(__dirname,'../app/src/main/assets/native-bridge.js'),'utf8');
const T0=1794840000000;

function setup(){
  const map=new Map(), calls=[], fixes=[];
  const storage={getItem:k=>map.has(k)?map.get(k):null,setItem:(k,v)=>map.set(k,String(v)),removeItem:k=>map.delete(k)};
  const host={onmessage:null,postMessage(raw){
    const q=JSON.parse(raw);calls.push(q);
    const answer=q.action==='points'?{points:fixes.filter(p=>p.seq>q.afterSeq).slice(0,q.limit)}:
      q.action==='state'?{activeId:host.activeId||'',paused:false,lastStoppedId:''}:{};
    queueMicrotask(()=>host.onmessage({data:JSON.stringify({id:q.id,ok:true,data:answer})}));
  }};
  const geo={watchPosition:()=>1,clearWatch(){},getCurrentPosition:fn=>fn({coords:{latitude:35,lng:126},timestamp:T0})};
  const ctx={window:{RiderSpotHost:host,addEventListener(){},dispatchEvent(){}},navigator:{geolocation:geo},document:{body:null,addEventListener(){}},sessionStorage:storage,localStorage:storage,location:{origin:'https://rider-spot.jazzhjm.workers.dev'},console,Promise,JSON,Map,Object,Set,Date,Number,Math,Array,setTimeout,clearTimeout,setInterval:()=>1,Event:class Event{constructor(type){this.type=type;}}};
  vm.createContext(ctx);vm.runInContext(script,ctx);
  return {ctx,fixes,storage,calls,detect:ctx.window.__rsNativeDetectStops,merge:ctx.window.__rsNativeStopMerge};
}
function fix(time,meters=0,accuracy=8,speed=0,baseLng=126.85){
  return {t:T0+time*1000,lat:35.2,lng:baseLng+meters/91000,accuracy,speed};
}
test('60+ seconds within 30m creates one timestamped stationary event with coordinates',()=>{
  const {detect}=setup();
  const points=Array.from({length:9},(_,i)=>fix(i*12,i%2?3:-3));
  const events=detect(points);
  assert.equal(events.length,1);
  assert.equal(events[0].type,'정차 · 1분 36초');
  assert.equal(events[0].at,new Date(T0).toISOString());
  assert.equal(events[0].end_at,new Date(T0+96000).toISOString());
  assert.equal(events[0].duration_seconds,96);
  assert.ok(Math.abs(events[0].lng-126.85)<0.0001);
  assert.equal(events[0].source,'riderspot-native-stop-v1');
});
test('short red light 48 seconds is not marked as stationary',()=>{
  const {detect}=setup();
  assert.equal(detect(Array.from({length:5},(_,i)=>fix(i*12,1))).length,0);
});
test('a GPS blackout does not count as staying in one place',()=>{
  const {detect}=setup();
  assert.equal(detect([fix(0),fix(12),fix(24),fix(90),fix(102),fix(114)]).length,0);
});
test('creeping slowly away from anchor never creates a false 1-minute stop',()=>{
  const {detect}=setup();
  assert.equal(detect(Array.from({length:11},(_,i)=>fix(i*12,i*12))).length,0);
});
test('duplicate provider fixes and low-accuracy jumps do not produce duplicate stops',()=>{
  const {detect}=setup();
  const points=Array.from({length:9},(_,i)=>fix(i*12,i%2?5:-3));
  points.splice(3,0,fix(24,4)); // repeat timestamp from fused provider
  points.splice(5,0,fix(35,250,90)); // discard inaccurate GPS outlier
  const events=detect(points);
  assert.equal(events.length,1);
});
test('two separate 60-second stops become exactly two events in chronological order',()=>{
  const {detect}=setup();
  const points=[...Array.from({length:7},(_,i)=>fix(i*12,2)), ...Array.from({length:7},(_,i)=>fix(120+i*12,1,8,0,126.855))];
  const stops=detect(points);
  assert.equal(stops.length,2);
  assert.ok(Date.parse(stops[1].at)>Date.parse(stops[0].at));
});
test('stops merge idempotently and retain start, resume and end events',()=>{
  const {detect,merge}=setup();
  const stops=detect(Array.from({length:9},(_,i)=>fix(i*12)));
  const manual=[{type:'운행 시작',at:new Date(T0-1000).toISOString()},{type:'운행 종료',at:new Date(T0+125000).toISOString()}];
  const once=merge(manual,stops),twice=merge(once,stops);
  assert.equal(once.length,3);
  assert.equal(JSON.stringify(once),JSON.stringify(twice));
  assert.deepEqual(Array.from(twice.map(e=>e.type)),['운행 시작','정차 · 1분 36초','운행 종료']);
});
test('stop timestamps and locations are written locally and uploaded only after finish',async()=>{
  const {ctx,fixes,storage,calls}=setup();
  const id='d1111111-1111-4111-8111-111111111111',uid='c2222222-2222-4222-8222-222222222222';
  const uploaded=[];
  ctx.window.__rsClient={auth:{getUser:async()=>({data:{user:{id:uid}}})},from:t=>({upsert:async row=>{assert.equal(t,'trips');uploaded.push(row);return {error:null};}})};
  const native=Array.from({length:10},(_,i)=>fix(i*12,i%2?4:0));
  native.forEach((p,i)=>fixes.push({...p,seq:i+1}));
  const api={trip:{id},paused:false,history:[],async finish(){
    const row={id,user_id:uid,started_at:new Date(T0-2000).toISOString(),ended_at:new Date(T0+130000).toISOString(),points:[],events:[{type:'운행 시작',at:new Date(T0-2000).toISOString()},{type:'운행 종료',at:new Date(T0+130000).toISOString()}],distance_km:0};
    storage.setItem('trips:'+uid,JSON.stringify([row]));this.trip=null;this.history=[row];
  }};
  ctx.window.__rsRideApi=api;
  assert.equal(uploaded.length,0);
  await api.finish();
  assert.equal(uploaded.length,1);
  const e=uploaded[0].events;
  assert.equal(e.length,3);
  assert.equal(e[1].source,'riderspot-native-stop-v1');
  assert.ok(Number.isFinite(e[1].lat)&&Number.isFinite(e[1].lng));
  const saved=JSON.parse(storage.getItem('trips:'+uid));
  assert.equal(saved[0].events[1].at,e[1].at);
  assert.equal(saved[0].points.length,native.length);
  assert.equal(storage.getItem('rs:pending:trips:'+uid),'[]');
  assert.ok(calls.some(q=>q.action==='stop'));
});


test('while recording, local stop events appear without a Supabase write',async()=>{
  const {ctx,fixes,storage}=setup();
  const id='d1111111-1111-4111-8111-111111111111',uid='c2222222-2222-4222-8222-222222222222';
  const uploads=[];
  ctx.window.RiderSpotHost.activeId=id;
  ctx.window.__rsClient={auth:{getUser:async()=>({data:{user:{id:uid}}})},
    from:()=>({upsert:async row=>{uploads.push(row);return {error:null};}})};
  ctx.window.__rsRideApi={trip:{id,events:[{type:'운행 시작',at:new Date(T0-1000).toISOString()}]},paused:false};
  Array.from({length:9},(_,i)=>fix(i*12,i%2?4:-4)).forEach((p,i)=>fixes.push({...p,seq:i+1}));
  await ctx.window.__rsNativeResume();
  await new Promise(resolve=>setTimeout(resolve,35));
  const active=JSON.parse(storage.getItem('rs:active:'+uid));
  assert.equal(active.events.filter(e=>e.source==='riderspot-native-stop-v1').length,1);
  assert.equal(uploads.length,0);
});

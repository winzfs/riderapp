const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const root=path.resolve(__dirname,'..');
const service=fs.readFileSync(path.join(root,'app/src/main/java/com/riderspot/android/TrackingService.java'),'utf8');
const store=fs.readFileSync(path.join(root,'app/src/main/java/com/riderspot/android/TrackStore.java'),'utf8');
const bridge=fs.readFileSync(path.join(root,'app/src/main/assets/native-bridge.js'),'utf8');
const activity=fs.readFileSync(path.join(root,'app/src/main/java/com/riderspot/android/MainActivity.java'),'utf8');
const gradle=fs.readFileSync(path.join(root,'app/build.gradle'),'utf8');

test('Google high-accuracy FusedLocationClient plus raw GPS and network fallback are enabled',()=>{
 assert.match(gradle,/play-services-location:21\.4\.0/);
 assert.match(service,/LocationServices\.getFusedLocationProviderClient/);
 assert.match(service,/LocationRequest\.Builder\(Priority\.PRIORITY_HIGH_ACCURACY, 2000L\)/);
 assert.match(service,/LocationManager\.GPS_PROVIDER, LocationManager\.NETWORK_PROVIDER/);
 assert.match(service,/requestLocationUpdates\(provider, 2000L, 0f, this, gpsThread\.getLooper\(\)\)/);
});
test('GPS persists on dedicated thread and is not dependent on WebView Activity screen',()=>{
 assert.match(service,/new HandlerThread\("RiderSpot-Location-Capture"\)/);
 assert.match(service,/acceptLocation\(Location location\)/);
 assert.match(service,/store\.saveLocation\(id, location\)/);
 assert.match(service,/START_STICKY/);
 assert.match(service,/PARTIAL_WAKE_LOCK/);
 assert.match(fs.readFileSync(path.join(root,'app/src/main/AndroidManifest.xml'),'utf8'),/android:stopWithTask="false"/);
});
test('watchdog restarts when no accepted points even with healthy provider callbacks',()=>{
 assert.match(service,/cbAge > CALLBACK_STALE_MS \|\| saveAge > SAVE_STALE_MS/);
 assert.match(service,/store\.noteGpsReconnect\(cbAge, saveAge\)/);
 assert.match(service,/RECONNECT_COOLDOWN_MS/);
 assert.match(store,/gpsReconnects/);
 assert.match(store,/gpsLastSavedAt/);
});
test('SQLite preserves delayed/out-of-order fixes and adds timestamp index without deleting data',()=>{
 assert.match(store,/recordedAt < now - 90 \* 60_000L/);
 assert.match(store,/CREATE INDEX IF NOT EXISTS idx_samples_trip_time/);
 assert.match(store,/newestLocationByTime/);
 assert.match(store,/getWritableDatabase\(\)\.insert\("samples"/);
 assert.doesNotMatch(store,/DROP TABLE/);
});
test('WebView route uses SQLite-accepted fixes while active and repairs service only while visible',()=>{
 assert.match(bridge,/const active = window\.__rsRideApi/);
 assert.match(bridge,/void drain\(active\.trip\.id\)/);
 assert.match(bridge,/state\.gpsServiceActive === false && !state\.paused && !document\.hidden/);
 assert.match(activity,/case "ensure-tracking":/);
 assert.match(activity,/!foreground \|\| !hasLocationPermission\(\)/);
});
test('route stays local during capture and is merged/uploaded only after finish',()=>{
 assert.match(store,/Nothing is uploaded by the native layer/);
 assert.match(bridge,/await finalizeNativeTrip\(trip\.id\)/);
 assert.match(bridge,/await window\.__rsClient\.from\('trips'\)\.upsert/);
 assert.match(service,/정확한 위치 기록 중 · 기기에만 저장/);
});

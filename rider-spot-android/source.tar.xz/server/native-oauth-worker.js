/* Add these handlers ahead of the ordinary Cloudflare Worker asset router.
 * Google OAuth is always executed in the system browser. The Supabase redirect
 * stays the existing approved first-party Site URL. Only a browser holding a
 * 10-minute, HttpOnly, same-site nonce cookie gets this callback HTML.
 * The HTML reads OAuth tokens from the URL fragment; fragments are never sent
 * to the server. This does not alter ordinary PWA/web Google logins.
 */
const RS_OAUTH_START = '/__rs_android_oauth_start';
const RS_SUPABASE_AUTH = 'https://qkcqzhkvfbymzjdktshp.supabase.co';
const RS_ORIGIN = 'https://rider-spot.jazzhjm.workers.dev';
const RS_COOKIE = 'rs_android_oauth';
const RS_NONCE_RE = /^[0-9a-f]{32}$/;

function rsHttpError(status, message) {
  return new Response(message, {
    status,
    headers:{'Content-Type':'text/plain; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'}
  });
}

function rsAuthCallbackHtml(state) {
  // state comes only from a validated server-side cookie. Never embed any
  // sensitive tokens in HTML or a server-visible query string.
  const safeState = JSON.stringify(state);
  return `<!doctype html><html lang="ko"><head><meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1"/>
<title>라이더스팟 앱 로그인</title>
<style>body{background:#f5faf8;color:#173c33;font-family:system-ui,sans-serif;display:grid;place-items:center;min-height:90vh;margin:0}.card{max-width:420px;margin:20px;padding:30px;border:1px solid #cce2da;border-radius:22px;background:#fff;text-align:center;line-height:1.8}a{display:block;background:#0a6452;color:white;text-decoration:none;font-weight:700;padding:13px 18px;border-radius:12px;margin-top:20px}small{color:#61786c}</style>
</head><body><main class="card"><h2>라이더스팟 로그인</h2><p id="message">인증을 확인하고 앱으로 돌아갑니다.</p><a id="return" href="#">라이더스팟 앱으로 돌아가기</a><small>앱이 자동으로 열리지 않으면 위 버튼을 눌러주세요.</small></main>
<script>/* No external scripts, no token logging or network requests. */
(function(){
  const state=${safeState};
  const fragment=location.hash || '';
  const params=new URLSearchParams(fragment.slice(1));
  const callback='riderspot-oauth://signin/callback?state='+encodeURIComponent(state)+fragment;
  const button=document.getElementById('return');
  const msg=document.getElementById('message');
  if(!params.has('access_token')&&!params.has('error')&&!params.has('error_code')){
    msg.textContent='로그인 인증 정보가 도착하지 않았어요. 라이더스팟 앱에서 다시 로그인해 주세요.';
    button.style.display='none';
    return;
  }
  button.href=callback;
  window.setTimeout(()=>{window.location.replace(callback)},120);
})();
</script></body></html>`;
}

async function handleRiderSpotOAuth(request, url) {
  if (url.pathname === RS_OAUTH_START) {
    if (request.method !== 'GET') return rsHttpError(405,'Method Not Allowed');
    const state=url.searchParams.get('state') || '';
    const target=url.searchParams.get('target') || '';
    if (!RS_NONCE_RE.test(state) || target.length > 4096) return rsHttpError(400,'Invalid Android login request');
    let auth;
    try { auth=new URL(target); } catch { return rsHttpError(400,'Invalid OAuth URL'); }
    if (auth.origin !== RS_SUPABASE_AUTH || auth.pathname !== '/auth/v1/authorize'
      || auth.searchParams.get('provider') !== 'google'
      || auth.searchParams.get('redirect_to') !== RS_ORIGIN + '/') {
      return rsHttpError(400,'Unsupported OAuth destination');
    }
    return new Response(null,{
      status:302,
      headers:{
        'Location':auth.toString(),
        'Set-Cookie':RS_COOKIE+'='+state+'; Max-Age=600; Path=/; Secure; HttpOnly; SameSite=Lax',
        'Cache-Control':'no-store','Referrer-Policy':'no-referrer','X-Content-Type-Options':'nosniff'
      }
    });
  }
  if (url.pathname === '/' && request.method === 'GET') {
    const cookie=(request.headers.get('Cookie')||'').split(';').map(x=>x.trim())
      .find(x=>x.startsWith(RS_COOKIE+'='));
    const state=cookie?cookie.substring((RS_COOKIE+'=').length):'';
    if (!RS_NONCE_RE.test(state)) return null; // Ordinary browsers are unchanged.
    return new Response(rsAuthCallbackHtml(state),{
      status:200,
      headers:{
        'Content-Type':'text/html; charset=utf-8',
        'Cache-Control':'no-store',
        'Set-Cookie':RS_COOKIE+'=; Max-Age=0; Path=/; Secure; HttpOnly; SameSite=Lax',
        'Referrer-Policy':'no-referrer',
        'X-Content-Type-Options':'nosniff',
        'X-Frame-Options':'DENY',
        'Content-Security-Policy':"default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; base-uri 'none'; frame-ancestors 'none'; form-action 'none'"
      }
    });
  }
  return null;
}

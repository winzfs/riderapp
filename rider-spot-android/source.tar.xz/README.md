# 라이더스팟 Android — 독립 네이티브 프로젝트

운영 중인 https://rider-spot.jazzhjm.workers.dev/ 를 Android WebView로 표시하고,
**화면 잠금 중에도 동작하는 안드로이드 전경 위치 서비스**로 운행 경로를 기록합니다.
기존 `winzfs/riderapp`(목적지 캡처 앱)과 전혀 별개의 코드입니다.

## 구현 범위

- Android 8 이상, Android 16 API 36 타깃, Java 17, Android Gradle Plugin 8.13.2.
- 기존 지도, 커뮤니티, 타임라인, 수익/정비, 로그인 화면을 운영 웹앱에서 사용.
- WebView 위치 권한 + GPS_PROVIDER/NETWORK_PROVIDER 이용.
- 운행 시작 때만 `location` 전경 서비스를 시작해 **화면 꺼짐/타 앱 전환에서도** 로컬 SQLite 저장.
- 권한/알림 채널/운행 종료 알림 버튼/일시정지 처리.
- GPS 위치 오차·정지 중 중복 좌표·과도한 이동 속도 필터.
- AndroidX WebKit origin allowlist(`https://rider-spot.jazzhjm.workers.dev`)와 메시지 기반 JS 브리지.
- 앱 화면 복귀 시 저장한 GPS 샘플을 원래 웹앱의 geolocation watch 콜백으로 재생해 React 타임라인 데이터에 합침.
- 앱이 리로드된 후 기존 `active:<user_id>` 키의 진행 중 운행을 복구.
- 네이티브 알림에서 종료했을 때도 기록을 웹 타임라인에 합쳐 최종 저장하도록 복구 로직.
- 서버로 운행기록 전송은 **기존 웹앱의 Supabase 인증·RLS·업로드**를 그대로 사용(네이티브 서비스에서 전송하지 않음).
- 커뮤니티 이미지 선택 지원.

## 제약과 주의

- **현재 파일은 빌드 전 소스**입니다. GitHub Actions에서 컴파일해 APK를 만들 수 있도록 워크플로가 포함되어 있습니다.
- 운영 웹앱을 로드하므로 첫 실행/로그인은 네트워크가 필요할 수 있습니다. 크롬 PWA와 WebView는 서로 다른 로그인/캐시 저장소를 사용합니다.
- GPS 운행기록은 화면 꺼짐에도 계속되지만 Android OS의 강제 종료, 배터리 제한, 사용자의 서비스 중지/권한 취소 때는 중단될 수 있습니다. 삼성 기기에서는 배터리 '제한 없음'을 권장합니다.
- **라이더 위치 공유는 웹앱의 기존 정책대로 앱을 백그라운드로 보내면 자동 중단됩니다.** 운행 기록과 위치 공개는 별개이며 백그라운드 위치 공개는 아직 구현하지 않았습니다.
- 정확한 위치 권한(FINE)을 허용하는 것이 오차 방지에 유리합니다. 알림 권한도 허용해 주세요.
- 기존 웹앱 React 코드에 노출된 `window.__rsRideApi` 및 데이터 저장 키에 연동하므로 운영 웹앱 코드가 변경되면 연동 수정이 필요할 수 있습니다.
- 물리 기기에서 아직 실제 장시간 운행 테스트를 마치지 않은 베타 빌드용 소스입니다. 정확성·배터리 소모·지연·네트워크 복구 검증 전 상용 서비스로 안내하면 안 됩니다.
- 프로덕션 배포는 개인 서명키로 별도 `release` 서명 및 Google Play 배포 정책 점검이 필요합니다. GitHub Actions 결과물은 테스트 설치용 **debug APK**입니다.

## 컴퓨터 없이 GitHub Actions로 APK 만들기

1. 휴대폰 브라우저에서 **새로운 독립 비공개 GitHub 저장소**(예: `rider-spot-android`)를 만듭니다. **`winzfs/riderapp`에는 업로드하지 마세요.**
2. 이 소스 ZIP을 GitHub Codespaces 또는 Android Studio가 있는 환경에서 풀고, 새 저장소의 루트에 업로드/커밋합니다. 숨김 `.github/workflows/android-apk.yml` 파일도 포함해야 합니다.
3. GitHub 저장소의 **Actions → Android APK → Run workflow**를 누릅니다. `main`에 소스가 push되면 자동으로도 빌드됩니다.
4. 성공한 workflow 실행 → **Artifacts → `rider-spot-android-debug-apk`** ZIP을 받습니다. 그 안의 `app-debug.apk` 파일을 삼성폰에서 설치합니다.
5. 첫 실행: 위치 정확하게 허용 → 운행 시작 → 알림 권한 허용 → 화면 잠금 5~10분 테스트 → 타임라인 경로 확인.

## Android Studio / Gradle

인터넷과 Android SDK 36/JDK 17이 있는 환경에서:

```bash
gradle :app:assembleDebug
```

생성 경로: `app/build/outputs/apk/debug/app-debug.apk`

## 현장 테스트 체크리스트

- 지도 현재 위치, 근처 라이더, 쉼터/화장실, GPS 권한 관련 오류 확인
- 10분간 운행 기록 시작 → 화면 잠금 → 기록 중 알림 유지 → 화면 켜기 → 누락 구간 보정 확인
- 타 앱(배민/쿠팡이츠) 10분 사용 → 기록 계속 여부 확인
- 일시정지 → 이동 → 경로가 늘어나지 않는지 / 재개 후 다시 늘어나는지 확인
- 통신 끊기 → 위치 기록 → 네트워크 복귀 → 운행 종료 → 서버 타임라인 동기화 확인
- Android 앱 강제 종료/로그아웃/배터리 제한 상태에서 정지·복구 정책 확인
- 위치 공유 ON/OFF(로그인 사용자) 및 백그라운드 진입 시 자동 OFF 확인
- 앱에서 이미지 첨부·외부 링크·로그인 기능 동작 확인

## 데이터 구조

네이티브 샘플은 내부 앱 전용 SQLite `rider_spot_locations.db`에 보관됩니다. 웹앱이 가져올 때 `{lat,lng,accuracy,heading,t}`로 전달하여 기존 Supabase `trips.points` JSON 형식으로 저장합니다.

안드로이드 앱이 직접 Supabase secret/service_role 키를 사용하지 않습니다. DB/Cloudflare 운영 설정을 수정하지 않았습니다.

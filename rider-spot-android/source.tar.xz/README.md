# Rider Spot Android v1.0.6 — GPS capture resilience

## Changes

- **High-accuracy fused location**: Google Play Services Location `21.4.0` (`PRIORITY_HIGH_ACCURACY`, 2-second interval, 1-second fastest) runs in a user-initiated Android foreground location service. Android GPS and network providers run as independent fallbacks.
- **Dedicated GPS callback thread**: Location callbacks and SQLite writes no longer depend on the WebView/UI main thread, so the route is recorded even if rendering is delayed, the screen is locked, or another app is in front.
- **GPS watchdog (10 sec)**: Detects absent accepted samples as well as missing provider callbacks, and reconnects after 35–40 seconds with a 30-second cooldown. Notification warns of delayed GPS, on-device diagnostics expose the last saved fix and reconnect count.
- **Preserve valid delayed GPS fixes**: SQLite `recorded_at` index, database migration without data deletion, timestamp-aware de-duplication, and acceptance of buffered fixes arriving out-of-order after screen wake. Never invent GPS samples.
- **One source of truth**: During recording, WebView GPS display receives route updates from *native SQLite* through the existing bridge, not separate foreground Activity callbacks that could cause mismatches.
- **Foreground recovery**: When Android stopped the GPS service and user later opens the app, the app may restart its own foreground service while the screen is visible. Does not attempt prohibited background service starts.
- The existing 60-second stop events, Android notification stop button, Google browser OAuth callback, and road-matching web UI remain intact.
- **Privacy**: During the ride GPS route is saved only on the device; the signed-in WebView uploads completed trips to Supabase when the user stops. Optional *rider-to-rider location sharing* is separate and not changed.

## Limitations and safety

- No API can guarantee uninterrupted positioning inside tunnels, GNSS-blocked areas, with location permissions revoked, or after Android force-stops the app. The foreground service must be started from a visible screen with precise location permission and notification access.
- The higher update frequency and partial CPU wake lock use more battery. Avoid suppressing the system's permission/notification controls.
- Not tested in a real multi-hour ride on Samsung hardware. Check `Settings > Apps > Rider Spot > Battery > Unrestricted`, precise location enabled, and notifications allowed.
- **Do not uninstall an existing version** while it has unsynced local trips. GitHub Actions debug builds may have different signing keys, requiring uninstall for installation. First verify the route is present on the server.

## Build

Run `node --test tests/*.test.cjs` then `gradle :app:assembleDebug` with Java 17, Android SDK 36, and Gradle 8.13 (CI setup). Workflow in `.github/workflows/android-apk.yml` or the isolated repository branch workflow.

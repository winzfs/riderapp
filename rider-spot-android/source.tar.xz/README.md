# 라이더스팟 v1.0.4 Android Google OAuth 복귀 수정

- 원인: Android WebView와 Chrome은 인증 세션 저장소가 달라 구글 OAuth가 Chrome에서 완료되어도 APK는 로그인되지 않았습니다.
- 해결: `signInWithOAuth(skipBrowserRedirect:true)`로 외부 시스템 브라우저에서 로그인 진행, 로그인 시작 시 일회용 nonce 발급 및 HttpOnly 쿠키를 Cloudflare Worker에서 설정합니다.
- Supabase 인증 후 기존 Site URL `https://rider-spot.jazzhjm.workers.dev/`로 돌아오면, 쿠키가 있는 브라우저에만 전용 완료 페이지를 표시합니다. 이 페이지는 URL fragment의 인증 정보를 **서버로 전송하지 않고** `riderspot-oauth://signin/callback` 딥링크로 앱에 전달합니다.
- `MainActivity`는 타임아웃과 일회용 nonce를 검증한 후 WebView 내 기존 Supabase 클라이언트의 `auth.setSession`으로 로그인 상태를 적용합니다. 자동 복귀가 차단될 경우 Chrome의 **라이더스팟 앱으로 돌아가기** 버튼을 사용합니다.
- Cloudflare Worker의 루트 동작을 일반 웹 방문자에 대해서는 변경하지 않습니다. 배포 시 `server/native-oauth-worker.js`의 함수를 기존 Worker 스크립트 앞에 추가하고 `export default fetch`에서 해당 함수를 먼저 호출해야 합니다.
- GPS 기기 전용 저장과 운행 종료 후 서버 전송, 알림 종료 기능은 기존 v1.0.3 그대로 유지합니다.
- **주의:** 디버그 서명이 달라 기존 APK 업데이트가 거부될 수 있습니다. 삭제 전 서버에 기록이 동기화되었는지 확인하세요. 실기기 OAuth 동작은 설치 후 검증이 필요합니다.
- 소스 검증: `node --test tests/*.test.cjs`.

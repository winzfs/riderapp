/* Rider Spot trusted-origin native integration. Injected at document start.
 * Only the app's own first-party page gets the WebMessage bridge.
 * Location recording is opt-in; native samples never leave the device directly.
 */
(() => {
  'use strict';
  if (window.__rsNativeInstalled || !window.RiderSpotHost) return;
  window.__rsNativeInstalled = true;
  const host = window.RiderSpotHost;
  let nextRequestId = 1;
  const pending = new Map();
  const watchers = new Map();
  let watchId = 100000;
  let currentApi = null;
  let draining = false;
  let reconciling = false;
  let initialized = false;

  host.onmessage = event => {
    try {
      const answer = JSON.parse(event.data);
      const item = pending.get(answer.id);
      if (!item) return;
      pending.delete(answer.id);
      if (answer.ok) item.resolve(answer.data);
      else item.reject(new Error(answer.error || 'GPS 요청 실패'));
    } catch (err) { console.warn('[RiderSpotNative] reply error', err); }
  };

  function send(action, extra = {}) {
    return new Promise((resolve, reject) => {
      const id = nextRequestId++;
      pending.set(id, { resolve, reject });
      try { host.postMessage(JSON.stringify({ id, action, ...extra })); }
      catch (error) { pending.delete(id); reject(error); }
    });
  }

  function notify(text) {
    if (!document.body) { console.warn('[RiderSpotNative]', text); return; }
    let bar = document.getElementById('rs-native-alert');
    if (!bar) {
      bar = document.createElement('div');
      bar.id = 'rs-native-alert';
      Object.assign(bar.style, {
        position:'fixed', top:'max(12px, env(safe-area-inset-top))', left:'12px', right:'12px',
        zIndex:'2147483600', padding:'12px 14px', background:'#153c33', color:'#fff',
        borderRadius:'12px', fontSize:'13px', lineHeight:'1.5', boxShadow:'0 6px 24px #0003'
      });
      document.body.appendChild(bar);
    }
    bar.textContent = text;
    clearTimeout(bar.__rsTimer);
    bar.__rsTimer = setTimeout(() => bar.remove(), 6500);
  }

  // Use Android LocationManager for foreground location updates. Unlike the
  // browser API, the native bridge uses THIS application's location permission.
  window.__rsNativePosition = point => {
    if (!point || !Number.isFinite(point.lat) || !Number.isFinite(point.lng)) return;
    for (const listener of watchers.values()) {
      try { listener.success(geoPosition(point)); }
      catch (err) { console.warn('[RiderSpotNative] watch listener', err); }
    }
  };
  window.__rsNativePermissionGranted = () => {
    if (watchers.size) send('geo-watch').catch(err => notify(err.message));
  };

  const actualGeo = navigator.geolocation;
  if (actualGeo) {
    const originalWatch = actualGeo.watchPosition.bind(actualGeo);
    const originalClear = actualGeo.clearWatch.bind(actualGeo);
    const originalCurrent = actualGeo.getCurrentPosition.bind(actualGeo);
    const proxy = {
      watchPosition(success, failure, options = {}) {
        if (typeof success !== 'function') throw new TypeError('GPS success callback required');
        const id = watchId++;
        watchers.set(id, {success, failure});
        if (watchers.size === 1) send('geo-watch').catch(err => {
          if (typeof failure === 'function') failure({code:2, message:err.message});
          notify('라이더스팟 위치 설정: ' + err.message);
        });
        return id;
      },
      clearWatch(id) {
        if (!watchers.has(id)) { originalClear(id); return; }
        watchers.delete(id);
        if (!watchers.size) send('geo-unwatch').catch(err => console.warn(err));
      },
      getCurrentPosition(success, failure, options = {}) {
        if (typeof success !== 'function') throw new TypeError('GPS success callback required');
        const maxAge = Math.max(0, Number(options.maximumAge) || 0);
        send('geo-current', { maxAge }).then(p => success(geoPosition(p))).catch(err => {
          if (typeof failure === 'function') failure({code:2, message:err.message});
          notify('라이더스팟 GPS: ' + err.message);
        });
      }
    };
    try { Object.defineProperty(navigator, 'geolocation', { configurable: true, get: () => proxy }); }
    catch (err) {
      console.warn('[RiderSpotNative] geolocation proxy unavailable', err);
      // Older WebViews continue using the correctly granted WebChromeClient route.
    }
  }

  async function activeState() {
    try { return await send('state'); } catch (err) { return null; }
  }

  function geoPosition(p) {
    return { coords: {
      latitude:p.lat, longitude:p.lng, accuracy:p.accuracy,
      heading:p.heading, speed:p.speed, altitude:null, altitudeAccuracy:null
    }, timestamp:p.t };
  }

  function getSeq(id) {
    return Number(sessionStorage.getItem('rs-native-seq:' + id)) || 0;
  }
  function setSeq(id, seq) {
    sessionStorage.setItem('rs-native-seq:' + id, String(seq));
  }

  async function drain(id) {
    if (!id || draining || watchers.size === 0) return;
    draining = true;
    try {
      let seq = getSeq(id);
      for (let page = 0; page < 90; page++) {
        const response = await send('points', { tripId:id, afterSeq:seq, limit:180 });
        const points = Array.isArray(response.points) ? response.points : [];
        if (!points.length) break;
        for (const point of points) {
          for (const listener of watchers.values()) {
            try { listener.success(geoPosition(point)); } catch (err) { console.error(err); }
          }
          seq = Math.max(seq, point.seq);
        }
        setSeq(id, seq);
        if (points.length < 180) break;
        // Yield to React before replaying the next batch.
        await new Promise(resolve => setTimeout(resolve, 16));
      }
    } catch (err) { console.warn('[RiderSpotNative] deferred replay', err); }
    finally { draining = false; }
  }

  function wrap(api) {
    if (!api || api.__rsWrapped) return api;
    Object.defineProperty(api, '__rsWrapped', {value:true});
    const start = api.startTrip;
    const finish = api.finish;
    const togglePause = api.togglePause;

    api.startTrip = async (...args) => {
      const answer = await start(...args);
      // React rerenders with trip.id after a successful fix. Never record on failure.
      for (let n = 0; n < 12; n++) {
        await new Promise(resolve => setTimeout(resolve, 100));
        const trip = window.__rsRideApi?.trip;
        if (trip && !trip.ended_at) {
          try { await send('start', { tripId:trip.id }); }
          catch (err) { notify('백그라운드 GPS 시작 실패 · ' + err.message); }
          break;
        }
      }
      return answer;
    };

    api.togglePause = async (...args) => {
      const trip = api.trip;
      const willPause = !api.paused;
      // Flush the last fixes BEFORE the React app enters paused mode.
      if (trip && willPause) await drain(trip.id);
      const result = togglePause(...args);
      if (trip) await send('pause', { tripId:trip.id, paused:willPause })
        .catch(err => notify('GPS 일시정지 설정 오류 · ' + err.message));
      return result;
    };

    api.finish = async (...args) => {
      const trip = api.trip;
      if (trip) {
        await drain(trip.id);
        await new Promise(resolve => setTimeout(resolve, 90));
        try { await send('stop', { tripId:trip.id }); }
        catch (err) { notify('GPS 기록 종료 처리 오류 · ' + err.message); }
      }
      return await finish(...args);
    };
    return api;
  }

  // Existing app writes __rsRideApi once on every React render.
  try {
    let lastApi = window.__rsRideApi || null;
    Object.defineProperty(window, '__rsRideApi', {
      configurable:true,
      get:() => lastApi,
      set:value => { lastApi = wrap(value); currentApi = lastApi; }
    });
    if (lastApi) { currentApi = lastApi = wrap(lastApi); }
  } catch (err) { console.warn('[RiderSpotNative] API wrapper failed', err); }

  // A separate first-party localStorage active trip survives WebView restarts.
  // The page normally restores it paused. The native state tells us whether
  // background capture was still running when the WebView was recreated.
  async function reconcile() {
    if (reconciling) return;
    reconciling = true;
    try {
      const state = await activeState();
      const api = window.__rsRideApi;
      if (!state || !api) return;
      if (state.activeId && api.trip?.id === state.activeId) {
        if (api.paused && !state.paused) {
          // React restored an active record in paused mode after reload.
          api.togglePause();
        } else if (!api.paused && state.paused) {
          // Respect the service's paused state.
          api.togglePause();
        }
        if (!window.__rsRideApi?.paused) await drain(state.activeId);
      } else if (state.activeId && !api.trip) {
        // Recovery without creating a second trip; see recoverMissingTrip().
        await recoverMissingTrip(state);
      } else if (!state.activeId && state.lastStoppedId && api.trip?.id === state.lastStoppedId) {
        await recoverStoppedTrip(state.lastStoppedId, api);
      }
    } finally { reconciling = false; }
  }

  async function loadAll(id) {
    let seq = 0;
    const points = [];
    for (let page = 0; page < 90; page++) {
      const batch = (await send('points', {tripId:id,afterSeq:seq,limit:180})).points || [];
      if (!batch.length) break;
      for (const p of batch) { points.push(p); seq = p.seq; }
      if (batch.length < 180) break;
    }
    return points;
  }

  function mergeTrip(trip, source) {
    const map = new Map();
    for (const p of trip.points || []) if (p?.t) map.set(String(p.t), p);
    for (const p of source) map.set(String(p.t), {
      lat:p.lat, lng:p.lng, accuracy:p.accuracy, heading:p.heading, t:p.t
    });
    const points = [...map.values()].sort((a,b) => a.t - b.t).slice(0,14999);
    let meters = 0;
    for (let i = 1; i < points.length; i++) {
      const a = points[i-1], b = points[i];
      const rad = Math.PI/180, dLat=(b.lat-a.lat)*rad, dLng=(b.lng-a.lng)*rad;
      const h=Math.sin(dLat/2)**2 + Math.cos(a.lat*rad)*Math.cos(b.lat*rad)*Math.sin(dLng/2)**2;
      const dist=6371000*2*Math.asin(Math.min(1,Math.sqrt(h)));
      if (dist > 4 && dist < 2500 && (b.t-a.t)>0) meters += dist;
    }
    return {...trip,points,distance_km:Math.round(meters/10)/100};
  }

  async function currentUserId() {
    try { return (await window.__rsClient?.auth.getUser())?.data?.user?.id || 'guest'; }
    catch { return 'guest'; }
  }

  async function recoverMissingTrip(state) {
    if (initialized && sessionStorage.getItem('rs-native-recovery:' + state.activeId)) return;
    if (!document.body || !window.__rsClient) return;
    initialized = true;
    const id = state.activeId;
    const userId = await currentUserId();
    const key = 'active:' + userId;
    let existing;
    try { existing = JSON.parse(localStorage.getItem(key) || 'null'); } catch { existing = null; }
    if (existing?.id === id) return;
    const points = await loadAll(id);
    if (!points.length) return;
    const restored = mergeTrip({
      id, user_id:userId === 'guest' ? null : userId,
      started_at:new Date(state.startedAt || points[0].t).toISOString(),
      ended_at:null, points:[], events:[{type:'네이티브 GPS 운행 복구',at:new Date().toISOString()}],
      distance_km:0
    }, points);
    localStorage.setItem(key, JSON.stringify(restored));
    sessionStorage.setItem('rs-native-recovery:' + id, '1');
    location.reload(); // Existing React app recovers its local active trip.
  }

  async function recoverStoppedTrip(id, api) {
    const marker = 'rs-native-finalize:' + id;
    if (sessionStorage.getItem(marker) === 'merged') {
      sessionStorage.removeItem(marker);
      if (api.trip?.id === id) await api.finish();
      return;
    }
    const userId = await currentUserId();
    const key = 'active:' + userId;
    let record;
    try { record = JSON.parse(localStorage.getItem(key) || 'null'); } catch { return; }
    if (!record || record.id !== id) return;
    const points = await loadAll(id);
    localStorage.setItem(key, JSON.stringify(mergeTrip(record, points)));
    sessionStorage.setItem(marker, 'merged');
    location.reload();
  }

  window.__rsNativeResume = () => { void reconcile(); };
  const timer = setInterval(() => { void reconcile(); }, 3000);
  document.addEventListener('visibilitychange', () => { if (!document.hidden) void reconcile(); });
  window.addEventListener('focus', () => { void reconcile(); });
})();

package com.riderspot.android;

import android.content.ContentValues;
import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.location.Location;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/** GPS samples are kept on-device. Nothing is uploaded by the native layer. */
public final class TrackStore extends SQLiteOpenHelper {
    private static final String DB = "rider_spot_locations.db";
    private final SharedPreferences preferences;

    public TrackStore(Context context) {
        super(context, DB, null, 2);
        preferences = context.getSharedPreferences("rider_spot_native", Context.MODE_PRIVATE);
    }

    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE sessions (trip_id TEXT PRIMARY KEY, started_at INTEGER NOT NULL, stopped_at INTEGER, paused INTEGER NOT NULL DEFAULT 0)");
        db.execSQL("CREATE TABLE samples (seq INTEGER PRIMARY KEY AUTOINCREMENT, trip_id TEXT NOT NULL, lat REAL NOT NULL, lng REAL NOT NULL, accuracy REAL NOT NULL, heading REAL, speed REAL, recorded_at INTEGER NOT NULL)");
        db.execSQL("CREATE INDEX idx_samples_trip_seq ON samples(trip_id,seq)");
        db.execSQL("CREATE INDEX idx_samples_trip_time ON samples(trip_id,recorded_at)");
    }

    @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Preserve existing trips and samples across beta upgrades.
        if (oldVersion < 2) db.execSQL("CREATE INDEX IF NOT EXISTS idx_samples_trip_time ON samples(trip_id,recorded_at)");
    }

    public synchronized String activeTrip() {
        return preferences.getString("active_trip", "");
    }

    public synchronized boolean isPaused() {
        return preferences.getBoolean("paused", false);
    }

    public synchronized boolean startTrip(String id) {
        if (id == null || !id.matches("[a-fA-F0-9-]{36}")) return false;
        String active = activeTrip();
        if (!active.isEmpty() && !active.equals(id)) return false;
        SQLiteDatabase db = getWritableDatabase();
        if (active.isEmpty()) {
            ContentValues session = new ContentValues();
            session.put("trip_id", id);
            session.put("started_at", System.currentTimeMillis());
            session.put("paused", 0);
            db.insertWithOnConflict("sessions", null, session, SQLiteDatabase.CONFLICT_IGNORE);
        }
        preferences.edit().putString("active_trip", id).putBoolean("paused", false)
            .putLong("session_start_ms", System.currentTimeMillis())
            .remove("last_stopped").apply();
        return true;
    }

    public synchronized void setPaused(String id, boolean paused) {
        if (!id.equals(activeTrip())) return;
        preferences.edit().putBoolean("paused", paused).apply();
        ContentValues cv = new ContentValues();
        cv.put("paused", paused ? 1 : 0);
        getWritableDatabase().update("sessions", cv, "trip_id=?", new String[]{id});
    }

    public synchronized void stopTrip(String id) {
        if (!id.equals(activeTrip())) return;
        ContentValues cv = new ContentValues();
        cv.put("stopped_at", System.currentTimeMillis());
        getWritableDatabase().update("sessions", cv, "trip_id=?", new String[]{id});
        preferences.edit().remove("active_trip").putBoolean("paused", false).putString("last_stopped", id).apply();
    }

    /** One durable, quality-controlled write per accepted GPS fix. */
    public synchronized boolean saveLocation(String id, Location loc) {
        if (!id.equals(activeTrip()) || isPaused()) return false;
        if (loc == null || !loc.hasAccuracy() || loc.getAccuracy() > 180f || loc.getAccuracy() <= 0f) return false;
        if (!Double.isFinite(loc.getLatitude()) || !Double.isFinite(loc.getLongitude())
            || Math.abs(loc.getLatitude()) > 90d || Math.abs(loc.getLongitude()) > 180d) return false;
        if (loc.getLatitude() == 0d && loc.getLongitude() == 0d) return false;
        long recordedAt = loc.getTime() > 0 ? loc.getTime() : System.currentTimeMillis();
        long now = System.currentTimeMillis();
        long startedAt = preferences.getLong("session_start_ms", now - 90 * 60_000L);
        // Batch-delivered locations on Samsung/Android can arrive after screen
        // wake, and different providers may return them out of timestamp order.
        // Do not silently discard these VALID past samples.
        if (recordedAt > now + 15_000L || recordedAt < startedAt - 15_000L
            || recordedAt < now - 90 * 60_000L) return false;

        // First reject a genuine duplicate from GPS & Play Fused Provider.
        // Index idx_samples_trip_time keeps this check cheap throughout a shift.
        try (Cursor c = getReadableDatabase().rawQuery(
            "SELECT lat,lng,accuracy,recorded_at FROM samples WHERE trip_id=? AND recorded_at BETWEEN ? AND ? "
                + "ORDER BY ABS(recorded_at - ?) LIMIT 1",
            new String[]{id,Long.toString(recordedAt-1800L),Long.toString(recordedAt+1800L),Long.toString(recordedAt)})) {
            if (c.moveToFirst()) {
                Location existing=new Location("existing");
                existing.setLatitude(c.getDouble(0));
                existing.setLongitude(c.getDouble(1));
                if (existing.distanceTo(loc) < 12f) return false;
            }
        }
        Location newest = newestLocationByTime(id);
        if (newest != null && recordedAt > newest.getTime()) {
            long deltaMs = recordedAt - newest.getTime();
            float meters = newest.distanceTo(loc);
            // Keep a stationary heartbeat every ~10sec to support 60s stops,
            // even when the high-accuracy provider reports nearly identical fixes.
            if (meters < 2.5f && deltaMs < 10_000L) return false;
            // Low-quality network positions should not overtake good GPS fixes.
            if (deltaMs < 20_000L && newest.getAccuracy() < 25f
                && loc.getAccuracy() > Math.max(90f, newest.getAccuracy() * 4f)) return false;
            // Avoid physically impossible jumps, but do not reject a good new
            // fix just because a weak older fix was previously recorded.
            if (deltaMs < 20_000L && deltaMs >= 1000L
                && meters / (deltaMs / 1000f) > 70f
                && loc.getAccuracy() > 30f) return false;
        }
        try (Cursor c = getReadableDatabase().rawQuery("SELECT COUNT(*) FROM samples WHERE trip_id=?",new String[]{id})) {
            if (c.moveToFirst() && c.getInt(0) >= 14_500) return false;
        }
        ContentValues cv = new ContentValues();
        cv.put("trip_id", id);
        cv.put("lat", loc.getLatitude());
        cv.put("lng", loc.getLongitude());
        cv.put("accuracy", loc.getAccuracy());
        cv.put("heading", loc.hasBearing() ? loc.getBearing() : 0);
        cv.put("speed", loc.hasSpeed() ? loc.getSpeed() : 0);
        cv.put("recorded_at", recordedAt);
        boolean saved = getWritableDatabase().insert("samples",null,cv) >= 0;
        if (saved) preferences.edit().putLong("gps_last_saved_at",now)
            .putString("gps_last_provider",loc.getProvider()==null?"unknown":loc.getProvider()).apply();
        return saved;
    }

    private Location newestLocationByTime(String id) {
        try (Cursor c=getReadableDatabase().rawQuery(
            "SELECT lat,lng,accuracy,heading,recorded_at FROM samples WHERE trip_id=? ORDER BY recorded_at DESC LIMIT 1",new String[]{id})) {
            if (!c.moveToFirst()) return null;
            Location l=new Location("stored");
            l.setLatitude(c.getDouble(0));
            l.setLongitude(c.getDouble(1));
            l.setAccuracy(c.getFloat(2));
            l.setBearing(c.getFloat(3));
            l.setTime(c.getLong(4));
            return l;
        }
    }

    /** Diagnostics remain on-device; never upload rider health or movement data. */
    public synchronized void noteGpsReconnect(long callbackAgeMs,long savedAgeMs) {
        int old=preferences.getInt("gps_reconnects",0);
        preferences.edit().putInt("gps_reconnects",old+1)
            .putString("gps_last_error","GPS 자동 재연결 (콜백 " + callbackAgeMs/1000 + "초, 저장 " + savedAgeMs/1000 + "초)")
            .apply();
    }
    public synchronized void noteGpsServiceActive(boolean value) {
        preferences.edit().putBoolean("gps_service_active",value).apply();
    }
    public synchronized void noteGpsError(String error) {
        preferences.edit().putString("gps_last_error",error == null ? "" : error).apply();
    }

    public synchronized JSONObject getState() throws JSONException {
        String id = activeTrip();
        JSONObject out = new JSONObject();
        out.put("activeId", id);
        out.put("paused", isPaused());
        out.put("lastStoppedId", preferences.getString("last_stopped", ""));
        out.put("gpsLastSavedAt",preferences.getLong("gps_last_saved_at",0L));
        out.put("gpsProvider",preferences.getString("gps_last_provider",""));
        out.put("gpsReconnects",preferences.getInt("gps_reconnects",0));
        out.put("gpsLastError",preferences.getString("gps_last_error",""));
        out.put("gpsServiceActive",preferences.getBoolean("gps_service_active",false));
        if (!id.isEmpty()) {
            try (Cursor c = getReadableDatabase().rawQuery(
                    "SELECT COUNT(*), MAX(recorded_at) FROM samples WHERE trip_id=?", new String[]{id})) {
                if (c.moveToFirst()) {
                    out.put("nativePointCount", c.getInt(0));
                    if (!c.isNull(1)) out.put("nativeLastFixAt", c.getLong(1));
                }
            }
            try (Cursor c = getReadableDatabase().rawQuery("SELECT started_at FROM sessions WHERE trip_id=?", new String[]{id})) {
                if (c.moveToFirst()) out.put("startedAt", c.getLong(0));
            }
        }
        return out;
    }

    public synchronized JSONArray getPoints(String id, long sinceSeq, int limit) throws JSONException {
        JSONArray out = new JSONArray();
        if (id == null || !id.matches("[a-fA-F0-9-]{36}")) return out;
        int cap = Math.max(1, Math.min(250, limit));
        try (Cursor c = getReadableDatabase().rawQuery(
                "SELECT seq,lat,lng,accuracy,heading,speed,recorded_at FROM samples WHERE trip_id=? AND seq>? ORDER BY seq ASC LIMIT " + cap,
                new String[]{id, Long.toString(Math.max(0,sinceSeq))})) {
            while (c.moveToNext()) {
                JSONObject p = new JSONObject();
                p.put("seq", c.getLong(0));
                p.put("lat", c.getDouble(1));
                p.put("lng", c.getDouble(2));
                p.put("accuracy", c.getDouble(3));
                p.put("heading", c.getDouble(4));
                p.put("speed", c.getDouble(5));
                p.put("t", c.getLong(6));
                out.put(p);
            }
        }
        return out;
    }
}

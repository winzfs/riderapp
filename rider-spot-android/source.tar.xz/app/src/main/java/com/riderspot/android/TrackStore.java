package com.riderspot.android;

import android.content.ContentValues;
import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.location.Location;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/** GPS samples are kept on-device. Nothing is uploaded by the native layer. */
public final class TrackStore extends SQLiteOpenHelper {
    private static final String DB = "rider_spot_locations.db";
    private final SharedPreferences preferences;

    public TrackStore(Context context) {
        super(context, DB, null, 1);
        preferences = context.getSharedPreferences("rider_spot_native", Context.MODE_PRIVATE);
    }

    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE sessions (trip_id TEXT PRIMARY KEY, started_at INTEGER NOT NULL, stopped_at INTEGER, paused INTEGER NOT NULL DEFAULT 0)");
        db.execSQL("CREATE TABLE samples (seq INTEGER PRIMARY KEY AUTOINCREMENT, trip_id TEXT NOT NULL, lat REAL NOT NULL, lng REAL NOT NULL, accuracy REAL NOT NULL, heading REAL, speed REAL, recorded_at INTEGER NOT NULL)");
        db.execSQL("CREATE INDEX idx_samples_trip_seq ON samples(trip_id,seq)");
    }

    @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) { }

    public synchronized String activeTrip() {
        return preferences.getString("active_trip", "");
    }

    public synchronized boolean isPaused() {
        return preferences.getBoolean("paused", false);
    }

    public synchronized boolean startTrip(String id) {
        if (id == null || !id.matches("[a-fA-F0-9-]{36}")) return false;
        String active = activeTrip();
        if (!active.isEmpty() && !active.equals(id)) return false;
        SQLiteDatabase db = getWritableDatabase();
        if (active.isEmpty()) {
            ContentValues session = new ContentValues();
            session.put("trip_id", id);
            session.put("started_at", System.currentTimeMillis());
            session.put("paused", 0);
            db.insertWithOnConflict("sessions", null, session, SQLiteDatabase.CONFLICT_IGNORE);
        }
        preferences.edit().putString("active_trip", id).putBoolean("paused", false).remove("last_stopped").apply();
        return true;
    }

    public synchronized void setPaused(String id, boolean paused) {
        if (!id.equals(activeTrip())) return;
        preferences.edit().putBoolean("paused", paused).apply();
        ContentValues cv = new ContentValues();
        cv.put("paused", paused ? 1 : 0);
        getWritableDatabase().update("sessions", cv, "trip_id=?", new String[]{id});
    }

    public synchronized void stopTrip(String id) {
        if (!id.equals(activeTrip())) return;
        ContentValues cv = new ContentValues();
        cv.put("stopped_at", System.currentTimeMillis());
        getWritableDatabase().update("sessions", cv, "trip_id=?", new String[]{id});
        preferences.edit().remove("active_trip").putBoolean("paused", false).putString("last_stopped", id).apply();
    }

    public synchronized boolean saveLocation(String id, Location loc) {
        if (!id.equals(activeTrip()) || isPaused()) return false;
        if (!loc.hasAccuracy() || loc.getAccuracy() > 85.0f || loc.getAccuracy() <= 0f) return false;
        long recordedAt = loc.getTime() > 0 ? loc.getTime() : System.currentTimeMillis();
        long now = System.currentTimeMillis();
        if (recordedAt < now - 120_000L || recordedAt > now + 10_000L) return false;
        Location prev = lastLocation(id);
        if (prev != null) {
            long deltaMs = recordedAt - prev.getTime();
            if (deltaMs <= 0) return false;
            float meters = prev.distanceTo(loc);
            if (deltaMs < 4_000 && meters < 35) return false;
            if (deltaMs < 20_000 && meters < 8) return false;
            if (deltaMs >= 1_000 && meters / (deltaMs / 1000f) > 55f) return false;
        }
        // Database and Supabase both cap a trip at 15,000 points.
        try (Cursor c = getReadableDatabase().rawQuery("SELECT COUNT(*) FROM samples WHERE trip_id=?", new String[]{id})) {
            if (c.moveToFirst() && c.getInt(0) >= 14_000) return false;
        }
        ContentValues cv = new ContentValues();
        cv.put("trip_id", id);
        cv.put("lat", loc.getLatitude());
        cv.put("lng", loc.getLongitude());
        cv.put("accuracy", loc.getAccuracy());
        cv.put("heading", loc.hasBearing() ? loc.getBearing() : 0);
        cv.put("speed", loc.hasSpeed() ? loc.getSpeed() : 0);
        cv.put("recorded_at", recordedAt);
        return getWritableDatabase().insert("samples", null, cv) >= 0;
    }

    private Location lastLocation(String id) {
        try (Cursor c = getReadableDatabase().rawQuery("SELECT lat,lng,accuracy,heading,recorded_at FROM samples WHERE trip_id=? ORDER BY seq DESC LIMIT 1", new String[]{id})) {
            if (!c.moveToFirst()) return null;
            Location l = new Location("stored");
            l.setLatitude(c.getDouble(0));
            l.setLongitude(c.getDouble(1));
            l.setAccuracy(c.getFloat(2));
            l.setBearing(c.getFloat(3));
            l.setTime(c.getLong(4));
            return l;
        }
    }

    public synchronized JSONObject getState() throws JSONException {
        String id = activeTrip();
        JSONObject out = new JSONObject();
        out.put("activeId", id);
        out.put("paused", isPaused());
        out.put("lastStoppedId", preferences.getString("last_stopped", ""));
        if (!id.isEmpty()) {
            try (Cursor c = getReadableDatabase().rawQuery("SELECT started_at FROM sessions WHERE trip_id=?", new String[]{id})) {
                if (c.moveToFirst()) out.put("startedAt", c.getLong(0));
            }
        }
        return out;
    }

    public synchronized JSONArray getPoints(String id, long sinceSeq, int limit) throws JSONException {
        JSONArray out = new JSONArray();
        if (id == null || !id.matches("[a-fA-F0-9-]{36}")) return out;
        int cap = Math.max(1, Math.min(250, limit));
        try (Cursor c = getReadableDatabase().rawQuery(
                "SELECT seq,lat,lng,accuracy,heading,speed,recorded_at FROM samples WHERE trip_id=? AND seq>? ORDER BY seq ASC LIMIT " + cap,
                new String[]{id, Long.toString(Math.max(0,sinceSeq))})) {
            while (c.moveToNext()) {
                JSONObject p = new JSONObject();
                p.put("seq", c.getLong(0));
                p.put("lat", c.getDouble(1));
                p.put("lng", c.getDouble(2));
                p.put("accuracy", c.getDouble(3));
                p.put("heading", c.getDouble(4));
                p.put("speed", c.getDouble(5));
                p.put("t", c.getLong(6));
                out.put(p);
            }
        }
        return out;
    }
}

package com.riderspot.android;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.webkit.GeolocationPermissions;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebResourceRequest;
import androidx.webkit.WebMessageCompat;
import androidx.webkit.WebViewCompat;
import androidx.webkit.WebViewFeature;
import org.json.JSONObject;
import org.json.JSONException;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.Collections;

/** Only the trusted Rider Spot origin receives the native GPS bridge. */
public final class MainActivity extends Activity {
    private static final String HOME = "https://rider-spot.jazzhjm.workers.dev/";
    private static final String ORIGIN = "https://rider-spot.jazzhjm.workers.dev";
    private static final int PERMISSION_REQUEST = 210;
    private static final int FILE_PICK = 211;
    private WebView webView;
    private TrackStore store;
    private GeolocationPermissions.Callback geoCallback;
    private String geoOrigin;
    private ValueCallback<Uri[]> fileCallback;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        store = new TrackStore(this);
        webView = new WebView(this);
        webView.setBackgroundColor(0xffFFFFFF);
        setContentView(webView);
        WebSettings config = webView.getSettings();
        config.setJavaScriptEnabled(true);
        config.setDomStorageEnabled(true);
        config.setDatabaseEnabled(true);
        config.setGeolocationEnabled(true);
        config.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        config.setAllowFileAccess(false);
        config.setAllowContentAccess(true); // Android content picker image uploads.
        config.setJavaScriptCanOpenWindowsAutomatically(false);
        config.setSupportMultipleWindows(false);
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri url = request.getUrl();
                if ("https".equals(url.getScheme()) && "rider-spot.jazzhjm.workers.dev".equals(url.getHost())) return false;
                if (request.isForMainFrame() && ("https".equals(url.getScheme()) || "http".equals(url.getScheme()))) {
                    try { startActivity(new Intent(Intent.ACTION_VIEW, url)); } catch (Exception ignored) { }
                }
                return true;
            }
            @Override public void onPageFinished(WebView view, String url) {
                if (url.startsWith(ORIGIN)) webView.evaluateJavascript("window.__rsNativeResume&&window.__rsNativeResume()", null);
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback callback) {
                if (!ORIGIN.equals(origin)) { callback.invoke(origin, false, false); return; }
                if (hasLocationPermission()) { callback.invoke(origin, true, false); return; }
                geoCallback = callback;
                geoOrigin = origin;
                askLocationPermission();
            }
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                try {
                    Intent chooser = params.createIntent();
                    startActivityForResult(chooser, FILE_PICK);
                    return true;
                } catch (Exception ex) {
                    fileCallback.onReceiveValue(null);
                    fileCallback = null;
                    return false;
                }
            }
        });

        if (!WebViewFeature.isFeatureSupported(WebViewFeature.WEB_MESSAGE_LISTENER)) {
            new AlertDialog.Builder(this).setMessage("Android System WebView 업데이트가 필요합니다. GPS 연동을 사용할 수 없습니다.")
                .setPositiveButton("확인", (dialog, which) -> dialog.dismiss()).show();
        } else {
            WebViewCompat.addWebMessageListener(webView, "RiderSpotHost", Collections.singleton(ORIGIN),
                (view, message, sourceOrigin, isMainFrame, replyProxy) -> {
                    if (!isMainFrame || !ORIGIN.equals(sourceOrigin.toString())) return;
                    if (message.getType() != WebMessageCompat.TYPE_STRING) return;
                    try {
                        JSONObject req = new JSONObject(message.getData());
                        JSONObject response = new JSONObject();
                        response.put("id", req.optInt("id"));
                        try {
                            response.put("ok", true);
                            response.put("data", processRequest(req));
                        } catch (Exception ex) {
                            response.put("ok", false);
                            response.put("error", ex.getMessage() == null ? "GPS 요청 실패" : ex.getMessage());
                        }
                        replyProxy.postMessage(response.toString());
                    } catch (JSONException ignored) { }
                });
        }
        if (WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) {
            WebViewCompat.addDocumentStartJavaScript(webView, readAsset("native-bridge.js"), Collections.singleton(ORIGIN));
        } else {
            // Older WebViews: integration is best-effort; update Android System WebView.
            webView.setWebViewClient(new WebViewClient() {
                @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                    Uri uri = request.getUrl();
                    if (ORIGIN.equals(uri.getScheme()+"://"+uri.getHost())) return false;
                    if (request.isForMainFrame() && "https".equals(uri.getScheme())) {
                        try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); } catch (Exception ignored) { }
                    }
                    return true;
                }
                @Override public void onPageFinished(WebView view, String url) {
                    if (url.startsWith(ORIGIN)) view.evaluateJavascript(readAsset("native-bridge.js"), null);
                }
            });
        }
        webView.loadUrl(HOME);
    }

    private String readAsset(String path) {
        try (InputStream input = getAssets().open(path); ByteArrayOutputStream buf = new ByteArrayOutputStream()) {
            byte[] b = new byte[4096]; int n;
            while ((n = input.read(b)) != -1) buf.write(b, 0, n);
            return buf.toString(StandardCharsets.UTF_8.name());
        } catch (Exception ex) { return ""; }
    }

    private JSONObject processRequest(JSONObject req) throws Exception {
        String action = req.optString("action");
        String id = req.optString("tripId");
        JSONObject result = new JSONObject();
        switch (action) {
            case "state": return store.getState();
            case "points":
                result.put("points", store.getPoints(id, req.optLong("afterSeq", 0L), req.optInt("limit", 200)));
                return result;
            case "start":
                if (android.os.Build.VERSION.SDK_INT >= 33
                    && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 212);
                }
                if (!hasLocationPermission()) { askLocationPermission(); throw new IllegalStateException("위치 권한을 허용한 뒤 다시 시작해 주세요"); }
                LocationManager lm = (LocationManager) getSystemService(LOCATION_SERVICE);
                if (!lm.isProviderEnabled(LocationManager.GPS_PROVIDER) && !lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {
                    startActivity(new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS));
                    throw new IllegalStateException("휴대폰 위치 서비스를 켜 주세요");
                }
                if (!store.startTrip(id)) throw new IllegalStateException("다른 운행이 기록 중이거나 운행 ID가 잘못되었습니다");
                try {
                    Intent intent = new Intent(this, TrackingService.class).setAction(TrackingService.ACTION_START).putExtra(TrackingService.EXTRA_ID, id);
                    startForegroundService(intent);
                } catch (RuntimeException ex) {
                    store.stopTrip(id);
                    throw new IllegalStateException("GPS 서비스 실행 실패: 위치 권한과 알림 설정을 확인해 주세요");
                }
                result.put("activeId", id); return result;
            case "pause":
                if (!id.equals(store.activeTrip())) throw new IllegalStateException("기록 중인 운행이 아닙니다");
                boolean paused = req.optBoolean("paused", false);
                store.setPaused(id, paused);
                startService(new Intent(this, TrackingService.class)
                    .setAction(paused ? TrackingService.ACTION_PAUSE : TrackingService.ACTION_RESUME)
                    .putExtra(TrackingService.EXTRA_ID, id));
                result.put("paused", paused); return result;
            case "stop":
                if (id.equals(store.activeTrip())) {
                    store.stopTrip(id);
                    stopService(new Intent(this, TrackingService.class));
                }
                result.put("stopped", true); return result;
            default: throw new IllegalArgumentException("알 수 없는 GPS 요청");
        }
    }

    private boolean hasLocationPermission() {
        return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
            || checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    private void askLocationPermission() {
        if (hasLocationPermission()) return;
        new AlertDialog.Builder(this).setTitle("운행 경로 기록")
            .setMessage("라이더스팟이 GPS로 이동 경로를 기록하려면 위치 권한이 필요합니다. 운행 시작 후에는 알림을 표시하며, 화면을 꺼도 기록됩니다. 다른 라이더에게 위치를 공유하는 기능은 별도입니다.")
            .setNegativeButton("나중에", (d,w) -> { if (geoCallback != null) { geoCallback.invoke(geoOrigin, false, false); geoCallback = null; } })
            .setPositiveButton("권한 설정", (d,w) -> requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, PERMISSION_REQUEST))
            .show();
    }

    @Override public void onRequestPermissionsResult(int code, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(code, permissions, results);
        if (code == PERMISSION_REQUEST && geoCallback != null) {
            geoCallback.invoke(geoOrigin, hasLocationPermission(), false);
            geoCallback = null;
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_PICK && fileCallback != null) {
            Uri[] values = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
            fileCallback.onReceiveValue(values);
            fileCallback = null;
        }
    }

    @Override protected void onResume() {
        super.onResume();
        if (webView != null) {
            webView.onResume();
            webView.evaluateJavascript("window.__rsNativeResume&&window.__rsNativeResume()", null);
        }
    }

    @Override protected void onPause() {
        if (webView != null) webView.onPause();
        super.onPause();
    }

    @Override public void onBackPressed() {
        if (webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }

    @Override protected void onDestroy() {
        if (webView != null) {
            webView.stopLoading();
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}

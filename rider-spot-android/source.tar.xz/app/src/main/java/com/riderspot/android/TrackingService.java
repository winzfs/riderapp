package com.riderspot.android;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ServiceInfo;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.os.SystemClock;
import android.util.Log;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.Priority;
import java.util.List;

/**
 * User-initiated, location-type foreground service. The sole persistence owner
 * is SQLite, NOT the Activity/WebView. Samples continue across screen-off,
 * external navigation apps and WebView renderer suspension.
 *
 * Fused Play Services tracking uses high-accuracy (2 seconds) and Android GPS
 * & network providers act as independent fallbacks. Sample deduplication and
 * timestamp ordering happen in TrackStore. No background server transfer.
 */
public final class TrackingService extends Service implements LocationListener {
    public static final String ACTION_START = "com.riderspot.android.START";
    public static final String ACTION_STOP = "com.riderspot.android.STOP";
    public static final String ACTION_PAUSE = "com.riderspot.android.PAUSE";
    public static final String ACTION_RESUME = "com.riderspot.android.RESUME";
    public static final String EXTRA_ID = "tripId";
    private static final String TAG = "RiderSpotGPS";
    private static final String CHANNEL = "rider_spot_gps";
    private static final int NOTIFICATION_ID = 4701;
    private static final long HEALTH_INTERVAL_MS = 10000L;
    private static final long CALLBACK_STALE_MS = 40000L;
    private static final long SAVE_STALE_MS = 35000L;
    private static final long RECONNECT_COOLDOWN_MS = 30000L;
    private static final long WAKE_LOCK_TIMEOUT_MS = 10 * 60 * 1000L;

    private TrackStore store;
    private LocationManager locationManager;
    private FusedLocationProviderClient fusedClient;
    private LocationCallback fusedCallback;
    private HandlerThread gpsThread;
    private final Handler main = new Handler(Looper.getMainLooper());
    private PowerManager.WakeLock recordingLock;
    private boolean listening;
    private boolean fusedListening;
    private boolean providerListening;
    private volatile long lastCallbackElapsed;
    private volatile long lastSavedElapsed;
    private long lastReconnectElapsed;
    private long lastStartElapsed;
    private boolean gpsWarning;
    private boolean destroyed;

    private final Runnable gpsHealthCheck = new Runnable() {
        @Override public void run() {
            if (destroyed || store == null || store.activeTrip().isEmpty() || store.isPaused()) return;
            long now = SystemClock.elapsedRealtime();
            // An active provider callback can contain stale/invalid locations.
            // Restart on no ACCEPTED fixes as well as on no callbacks.
            long cbAge = lastCallbackElapsed == 0 ? now-lastStartElapsed : now-lastCallbackElapsed;
            long saveAge = lastSavedElapsed == 0 ? now-lastStartElapsed : now-lastSavedElapsed;
            boolean problem = !listening || cbAge > CALLBACK_STALE_MS || saveAge > SAVE_STALE_MS;
            if (problem && now-lastReconnectElapsed > RECONNECT_COOLDOWN_MS) {
                lastReconnectElapsed = now;
                store.noteGpsReconnect(cbAge, saveAge);
                Log.w(TAG, "GPS health reconnect; callbackAge="+cbAge+", savedAge="+saveAge);
                stopListening(false);
                startListening();
            }
            if (problem != gpsWarning) {
                gpsWarning = problem;
                updateNotification();
            }
            main.postDelayed(this, HEALTH_INTERVAL_MS);
        }
    };

    private final Runnable renewWakeLock = new Runnable() {
        @Override public void run() {
            if (!destroyed && store != null && !store.activeTrip().isEmpty() && !store.isPaused()) {
                releaseRecordingLock();
                acquireRecordingLock();
                main.postDelayed(this, 8 * 60 * 1000L);
            }
        }
    };

    @Override public void onCreate() {
        super.onCreate();
        store = new TrackStore(this);
        locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
        gpsThread = new HandlerThread("RiderSpot-Location-Capture");
        gpsThread.start();
        try { fusedClient = LocationServices.getFusedLocationProviderClient(this); }
        catch (RuntimeException | LinkageError e) { Log.w(TAG, "Play Services unavailable, GPS-only fallback", e); }
        NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        manager.createNotificationChannel(new NotificationChannel(CHANNEL, "라이더스팟 GPS 운행 기록", NotificationManager.IMPORTANCE_LOW));
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? ACTION_START : intent.getAction();
        String id = intent == null ? store.activeTrip() : intent.getStringExtra(EXTRA_ID);
        if (id == null) id = "";
        if (ACTION_STOP.equals(action)) {
            finishService(true);
            return START_NOT_STICKY;
        }
        if (id.isEmpty() || !id.equals(store.activeTrip())) {
            finishService(false);
            return START_NOT_STICKY;
        }
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(NOTIFICATION_ID, notification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION);
            } else {
                startForeground(NOTIFICATION_ID, notification());
            }
            if (ACTION_PAUSE.equals(action) || ACTION_RESUME.equals(action)) {
                store.setPaused(id, ACTION_PAUSE.equals(action));
            }
            if (store.isPaused()) {
                main.removeCallbacks(gpsHealthCheck);
                stopListening(true);
            } else {
                startListening();
                main.removeCallbacks(gpsHealthCheck);
                main.postDelayed(gpsHealthCheck, HEALTH_INTERVAL_MS);
            }
            updateNotification();
        } catch (RuntimeException ex) {
            Log.e(TAG, "Cannot start foreground location tracking", ex);
            store.noteGpsError("전경 위치 서비스 실패: " + ex.getClass().getSimpleName());
            stopListening(true);
            store.noteGpsServiceActive(false);
            stopSelf();
            return START_NOT_STICKY;
        }
        store.noteGpsServiceActive(true);
        return START_STICKY;
    }

    private void finishService(boolean markStopped) {
        main.removeCallbacks(gpsHealthCheck);
        stopListening(true);
        String active=store.activeTrip();
        if (markStopped && !active.isEmpty()) store.stopTrip(active);
        store.noteGpsServiceActive(false);
        stopForeground(STOP_FOREGROUND_REMOVE);
        stopSelf();
    }

    private void startListening() {
        if (listening || destroyed || store.isPaused() || store.activeTrip().isEmpty()) return;
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
            && checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            store.noteGpsError("정확한 위치 권한이 필요합니다");
            gpsWarning = true; updateNotification(); return;
        }
        boolean any = false;
        // A dedicated callback thread prevents UI/React/WebView jank from
        // delaying GPS database writes while the screen is ON.
        for (String provider : new String[]{LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER}) {
            try {
                if (locationManager.isProviderEnabled(provider)) {
                    locationManager.requestLocationUpdates(provider, 2000L, 0f, this, gpsThread.getLooper());
                    any = true;
                    providerListening = true;
                }
            } catch (SecurityException | IllegalArgumentException e) {
                Log.w(TAG, "Provider " + provider + " unavailable", e);
            }
        }
        // Google Fused Location Provider combines GNSS, WiFi, cell and sensors,
        // and is the recommended primary high-accuracy source on Galaxy phones.
        if (fusedClient != null) {
            try {
                if (fusedCallback == null) {
                    fusedCallback = new LocationCallback() {
                        @Override public void onLocationResult(LocationResult result) {
                            List<Location> locations = result.getLocations();
                            for (Location location : locations) acceptLocation(location);
                        }
                    };
                }
                LocationRequest request = new LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, 2000L)
                    .setMinUpdateIntervalMillis(1000L)
                    .setMaxUpdateDelayMillis(0L)
                    .setMinUpdateDistanceMeters(0f)
                    .setWaitForAccurateLocation(false)
                    .build();
                fusedClient.requestLocationUpdates(request, fusedCallback, gpsThread.getLooper())
                    .addOnSuccessListener(unused -> { fusedListening = true; })
                    .addOnFailureListener(error -> {
                        fusedListening = false;
                        Log.w(TAG, "Fused location failed; raw GPS fallback active", error);
                        store.noteGpsError("통합 위치 서비스 연결 실패 · 기기 GPS로 기록 중");
                        main.post(this::updateNotification);
                    });
                any = true;
            } catch (RuntimeException | LinkageError e) {
                Log.w(TAG, "Fused location could not start", e);
            }
        }
        listening = any;
        lastStartElapsed = SystemClock.elapsedRealtime();
        gpsWarning = !any;
        if (!any) store.noteGpsError("활성화된 GPS 위치 공급자를 찾지 못했습니다");
        acquireRecordingLock();
        main.removeCallbacks(renewWakeLock);
        main.postDelayed(renewWakeLock, 8 * 60 * 1000L);
        updateNotification();
    }

    private void stopListening(boolean releaseLock) {
        if (locationManager != null) {
            try { locationManager.removeUpdates(this); } catch (SecurityException e) { Log.w(TAG, "removeUpdates", e); }
        }
        if (fusedClient != null && fusedCallback != null) {
            try { fusedClient.removeLocationUpdates(fusedCallback); }
            catch (RuntimeException e) { Log.w(TAG, "stop Fused", e); }
        }
        providerListening = false;
        fusedListening = false;
        listening = false;
        if (releaseLock) {
            main.removeCallbacks(renewWakeLock);
            releaseRecordingLock();
        }
    }

    private void acceptLocation(Location location) {
        lastCallbackElapsed = SystemClock.elapsedRealtime();
        String id=store.activeTrip();
        if (id.isEmpty() || store.isPaused()) return;
        boolean saved=false;
        try { saved=store.saveLocation(id, location); }
        catch (RuntimeException e) { Log.e(TAG,"SQLite location write failed",e); store.noteGpsError("GPS 데이터 저장 실패"); }
        if (saved) {
            lastSavedElapsed = SystemClock.elapsedRealtime();
            if (gpsWarning) {
                main.post(() -> { gpsWarning=false; updateNotification(); });
            }
        }
    }

    @Override public void onLocationChanged(Location location) { acceptLocation(location); }
    @Override public void onProviderEnabled(String provider) { main.post(() -> {
        if (!store.activeTrip().isEmpty() && !store.isPaused() && !listening) startListening();
    }); }
    @Override public void onProviderDisabled(String provider) { main.post(() -> {
        if (!store.activeTrip().isEmpty() && !store.isPaused()) {
            // Do not tear down healthy Play Fused/GPS providers just because
            // a secondary network location source was toggled.
            main.removeCallbacks(gpsHealthCheck); main.post(gpsHealthCheck);
        }
    }); }

    private void acquireRecordingLock() {
        if (recordingLock == null) {
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            if (pm == null) return;
            recordingLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "RiderSpot:RouteCapture");
            recordingLock.setReferenceCounted(false);
        }
        if (!recordingLock.isHeld()) recordingLock.acquire(WAKE_LOCK_TIMEOUT_MS);
    }
    private void releaseRecordingLock() {
        if (recordingLock != null && recordingLock.isHeld()) recordingLock.release();
    }

    private Notification notification() {
        Intent home=new Intent(this, MainActivity.class).setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent open=PendingIntent.getActivity(this,1,home,PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Intent stop=new Intent(this,MainActivity.class).setAction(MainActivity.ACTION_FINISH_FROM_NOTIFICATION)
            .setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent end=PendingIntent.getActivity(this, 2, stop,PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        boolean paused=store.isPaused();
        return new Notification.Builder(this,CHANNEL)
            .setSmallIcon(R.drawable.ic_stat_location)
            .setContentTitle(paused ? "라이더스팟 · 일시정지" : "라이더스팟 · GPS 운행 기록 중")
            .setContentText(paused ? "운행 일시정지 · 종료는 아래 버튼" :
                gpsWarning ? "GPS 저장 지연 · 자동 재연결 중 · 원본 기록은 보존" :
                "정확한 위치 기록 중 · 기기에만 저장")
            .setCategory(Notification.CATEGORY_SERVICE).setContentIntent(open)
            .setOngoing(true).setOnlyAlertOnce(true)
            .addAction(new Notification.Action.Builder(R.drawable.ic_stat_location,"운행 종료",end).build())
            .build();
    }
    private void updateNotification() {
        NotificationManager manager=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        manager.notify(NOTIFICATION_ID,notification());
    }
    @Override public void onTaskRemoved(Intent rootIntent) {
        // The user-started foreground tracking service remains active even if
        // the user swipes the UI task away; Android may still kill the process.
        super.onTaskRemoved(rootIntent);
    }
    @Override public void onDestroy() {
        destroyed=true;
        main.removeCallbacks(gpsHealthCheck);
        main.removeCallbacks(renewWakeLock);
        stopListening(true);
        store.noteGpsServiceActive(false);
        if (gpsThread != null) gpsThread.quitSafely();
        super.onDestroy();
    }
    @Override public IBinder onBind(Intent intent) { return null; }
}

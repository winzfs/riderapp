package com.riderspot.android;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ServiceInfo;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.IBinder;
import android.os.Looper;

/** User-started foreground GPS capture, surviving screen-off and Activity backgrounding. */
public final class TrackingService extends Service implements LocationListener {
    public static final String ACTION_START = "com.riderspot.android.START";
    public static final String ACTION_STOP = "com.riderspot.android.STOP";
    public static final String ACTION_PAUSE = "com.riderspot.android.PAUSE";
    public static final String ACTION_RESUME = "com.riderspot.android.RESUME";
    public static final String EXTRA_ID = "tripId";
    private static final String CHANNEL = "rider_spot_gps";
    private static final int NOTIFICATION_ID = 4701;
    private TrackStore store;
    private LocationManager locationManager;
    private boolean listening;

    @Override public void onCreate() {
        super.onCreate();
        store = new TrackStore(this);
        locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
        NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        manager.createNotificationChannel(new NotificationChannel(CHANNEL, "라이더스팟 GPS 운행 기록", NotificationManager.IMPORTANCE_LOW));
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? "" : intent.getAction();
        String id = intent == null ? "" : intent.getStringExtra(EXTRA_ID);
        if (id == null) id = "";
        if (ACTION_STOP.equals(action)) {
            stopListening();
            String active = store.activeTrip();
            if (!active.isEmpty()) store.stopTrip(active);
            stopForeground(STOP_FOREGROUND_REMOVE);
            stopSelf();
            return START_NOT_STICKY;
        }
        if (id.isEmpty() || !id.equals(store.activeTrip())) {
            stopSelf();
            return START_NOT_STICKY;
        }
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(NOTIFICATION_ID, notification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION);
            } else {
                startForeground(NOTIFICATION_ID, notification());
            }
            if (ACTION_PAUSE.equals(action) || ACTION_RESUME.equals(action)) {
                store.setPaused(id, ACTION_PAUSE.equals(action));
            }
            if (store.isPaused()) stopListening(); else startListening();
            updateNotification();
        } catch (SecurityException ex) {
            stopListening();
            store.stopTrip(id);
            stopSelf();
        }
        return START_NOT_STICKY;
    }

    private void startListening() {
        if (listening) return;
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
            && checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) return;
        boolean any = false;
        for (String provider : new String[]{LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER}) {
            try {
                if (locationManager.isProviderEnabled(provider)) {
                    locationManager.requestLocationUpdates(provider, 5000L, 8f, this, Looper.getMainLooper());
                    any = true;
                }
            } catch (IllegalArgumentException | SecurityException ex) {
                // Provider unavailable; the other provider may still produce fixes.
            }
        }
        listening = any;
    }

    private void stopListening() {
        if (!listening) return;
        try { locationManager.removeUpdates(this); } catch (SecurityException ignored) { }
        listening = false;
    }

    @Override public void onLocationChanged(Location location) {
        String id = store.activeTrip();
        if (!id.isEmpty() && !store.isPaused()) store.saveLocation(id, location);
    }

    @Override public void onProviderEnabled(String provider) { if (!store.isPaused()) startListening(); }
    @Override public void onProviderDisabled(String provider) { /* other providers may still be active */ }

    private Notification notification() {
        Intent home = new Intent(this, MainActivity.class).setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent open = PendingIntent.getActivity(this, 1, home, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Intent stop = new Intent(this, TrackingService.class).setAction(ACTION_STOP);
        PendingIntent end = PendingIntent.getService(this, 2, stop, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        boolean paused = store.isPaused();
        return new Notification.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat_location)
            .setContentTitle(paused ? "라이더스팟 · 일시정지" : "라이더스팟 · GPS 운행 기록 중")
            .setContentText(paused ? "앱으로 돌아가 운행을 재개할 수 있어요" : "화면이 꺼져도 위치를 기록합니다")
            .setContentIntent(open).setOngoing(true).setOnlyAlertOnce(true)
            .addAction(new Notification.Action.Builder(null, "기록 종료", end).build())
            .build();
    }

    private void updateNotification() {
        NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        manager.notify(NOTIFICATION_ID, notification());
    }

    @Override public void onDestroy() {
        stopListening();
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}

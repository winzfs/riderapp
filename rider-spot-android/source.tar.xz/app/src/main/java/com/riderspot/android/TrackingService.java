package com.riderspot.android;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ServiceInfo;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.IBinder;
import android.os.Looper;
import android.os.Handler;
import android.os.PowerManager;

/** User-started foreground GPS capture, surviving screen-off and Activity backgrounding. */
public final class TrackingService extends Service implements LocationListener {
    public static final String ACTION_START = "com.riderspot.android.START";
    public static final String ACTION_STOP = "com.riderspot.android.STOP";
    public static final String ACTION_PAUSE = "com.riderspot.android.PAUSE";
    public static final String ACTION_RESUME = "com.riderspot.android.RESUME";
    public static final String EXTRA_ID = "tripId";
    private static final String CHANNEL = "rider_spot_gps";
    private static final int NOTIFICATION_ID = 4701;
    private TrackStore store;
    private LocationManager locationManager;
    private boolean listening;
    private PowerManager.WakeLock recordingLock;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private static final long WAKE_LOCK_TIMEOUT_MS = 10 * 60 * 1000L;
    // Bound every acquisition and renew only for a user-started active recording.
    private final Runnable refreshLock = new Runnable() {
        @Override public void run() {
            if (store != null && !store.activeTrip().isEmpty() && !store.isPaused() && listening) {
                releaseRecordingLock();
                acquireRecordingLock();
                handler.postDelayed(this, 8 * 60 * 1000L);
            }
        }
    };

    @Override public void onCreate() {
        super.onCreate();
        store = new TrackStore(this);
        locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
        NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        manager.createNotificationChannel(new NotificationChannel(CHANNEL, "라이더스팟 GPS 운행 기록", NotificationManager.IMPORTANCE_LOW));
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? ACTION_START : intent.getAction();
        String id = intent == null ? store.activeTrip() : intent.getStringExtra(EXTRA_ID);
        if (id == null) id = "";
        if (ACTION_STOP.equals(action)) {
            stopListening();
            String active = store.activeTrip();
            if (!active.isEmpty()) store.stopTrip(active);
            stopForeground(STOP_FOREGROUND_REMOVE);
            stopSelf();
            return START_NOT_STICKY;
        }
        if (id.isEmpty() || !id.equals(store.activeTrip())) {
            stopListening();
            stopSelf();
            return START_NOT_STICKY;
        }
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(NOTIFICATION_ID, notification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION);
            } else {
                startForeground(NOTIFICATION_ID, notification());
            }
            if (ACTION_PAUSE.equals(action) || ACTION_RESUME.equals(action)) {
                store.setPaused(id, ACTION_PAUSE.equals(action));
            }
            if (store.isPaused()) stopListening(); else startListening();
            updateNotification();
        } catch (RuntimeException ex) {
            // Leave the local trip recoverable rather than silently reporting GPS
            // tracking as active after a foreground-service permission failure.
            stopListening();
            store.stopTrip(id);
            stopSelf();
            return START_NOT_STICKY;
        }
        return START_STICKY;
    }

    private void startListening() {
        if (listening) return;
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
            && checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) return;
        boolean any = false;
        // A distance threshold of 8m used to suppress samples while stationary,
        // generating false-looking route gaps on screen-off. Request 0m then
        // do quality/duplication filtering in TrackStore instead.
        String[] providers = Build.VERSION.SDK_INT >= 31
            ? new String[]{LocationManager.FUSED_PROVIDER, LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER}
            : new String[]{LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER};
        for (String provider : providers) {
            try {
                if (locationManager.isProviderEnabled(provider)) {
                    locationManager.requestLocationUpdates(provider, 3000L, 0f, this, Looper.getMainLooper());
                    any = true;
                }
            } catch (IllegalArgumentException | SecurityException ex) {
                // Provider unavailable; other providers can still deliver fixes.
            }
        }
        listening = any;
        if (listening && !store.isPaused()) {
            acquireRecordingLock();
            handler.removeCallbacks(refreshLock);
            handler.postDelayed(refreshLock, 8 * 60 * 1000L);
        }
    }

    private void stopListening() {
        handler.removeCallbacks(refreshLock);
        releaseRecordingLock();
        if (!listening) return;
        try { locationManager.removeUpdates(this); } catch (SecurityException ignored) { }
        listening = false;
    }

    private void acquireRecordingLock() {
        if (recordingLock == null) {
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            if (pm == null) return;
            recordingLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "RiderSpot:RouteCapture");
            recordingLock.setReferenceCounted(false);
        }
        if (!recordingLock.isHeld()) recordingLock.acquire(WAKE_LOCK_TIMEOUT_MS);
    }

    private void releaseRecordingLock() {
        if (recordingLock != null && recordingLock.isHeld()) recordingLock.release();
    }

    @Override public void onLocationChanged(Location location) {
        String id = store.activeTrip();
        if (!id.isEmpty() && !store.isPaused()) store.saveLocation(id, location);
    }

    @Override public void onProviderEnabled(String provider) {
        if (store != null && !store.activeTrip().isEmpty() && !store.isPaused()) {
            stopListening();
            startListening();
        }
    }
    @Override public void onProviderDisabled(String provider) {
        if (store != null && !store.activeTrip().isEmpty() && !store.isPaused()) {
            stopListening();
            startListening();
        }
    }

    private Notification notification() {
        Intent home = new Intent(this, MainActivity.class).setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent open = PendingIntent.getActivity(this, 1, home, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Intent stop = new Intent(this, TrackingService.class).setAction(ACTION_STOP);
        PendingIntent end = PendingIntent.getService(this, 2, stop, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        boolean paused = store.isPaused();
        return new Notification.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat_location)
            .setContentTitle(paused ? "라이더스팟 · 일시정지" : "라이더스팟 · GPS 운행 기록 중")
            .setContentText(paused ? "앱으로 돌아가 운행을 재개할 수 있어요" : "화면이 꺼져도 위치를 기록합니다")
            .setContentIntent(open).setOngoing(true).setOnlyAlertOnce(true)
            .addAction(new Notification.Action.Builder(null, "기록 종료", end).build())
            .build();
    }

    private void updateNotification() {
        NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        manager.notify(NOTIFICATION_ID, notification());
    }

    @Override public void onDestroy() {
        stopListening();
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
